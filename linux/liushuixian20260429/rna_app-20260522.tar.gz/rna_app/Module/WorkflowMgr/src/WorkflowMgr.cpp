#include <vector>
#include <string>
#include <sstream>

#include "WorkflowMgr.h"
#include "Logger.h"
#include "cJSON.h"

using namespace std;

vector<string> StringSplit(string ori, char split) {
    vector<string>substrs;
    istringstream iss(ori);
    string substr;
    while (getline(iss, substr, split))
    {
        substrs.push_back(substr);
    }
    return substrs;  
}

WorkflowMgr* WorkflowMgr::instance = NULL;

WorkflowMgr& WorkflowMgr::GetInstance() {
    if (instance == NULL) {
        instance = new WorkflowMgr();
    }

    return *instance;
}

int WorkflowMgr::InitWorkflowMgr(u_int32_t seq_id, char* template_name, u_int8_t current_phase, u_int32_t current_phase_step) {
    vector<string>substrs;

    if (template_name == NULL) {
        err_printf("Input err, template name is NULL.\n");
        return -1;
    }

    seq_id_ = seq_id;
    template_name_.assign(template_name);
    /*substrs = StringSplit(template_name_, '-');
    if (!substrs.empty()) {
        sub_template_name_.assign(substrs[0]);
    } else {
        sub_template_name_.assign(template_name);
    }*/
    if (template_name_.length() >= 2) {
        sub_template_name_.assign(template_name_.substr(0,2));
    } else {
        sub_template_name_.assign(template_name);
    }

    current_phase_ = current_phase;
    current_phase_step_ = current_phase_step;
    last_heat_step_idx_ = 0;
    total_step_ = 0;
    gettimeofday(&start_time_, NULL);

    return 0;
}

u_int32_t WorkflowMgr::GetSeqId() {
    return seq_id_;
}

void WorkflowMgr::SetCurrentPhase(u_int8_t current_phase) {
    current_phase_ = current_phase;
}

void WorkflowMgr::SetCurrentPhaseStep(u_int32_t current_phase_step) {
    current_phase_step_ = current_phase_step;
}

void WorkflowMgr::SetLastHeatStepIdx(u_int32_t step_idx) {
    last_heat_step_idx_ = step_idx;
}

u_int32_t WorkflowMgr::GetLastHeatStepIdx() {
    return last_heat_step_idx_;
}

int  WorkflowMgr::GetTemplateName(char* name) {
    if (name == NULL) {
        err_printf("Input err, sub name ptr is NULL.\n");
        return -1;
    }
    
    snprintf(name, MAX_TEMPLATE_NAME_LEN, "%s", template_name_.c_str());
    return 0;
}

int WorkflowMgr::GetSubTemplateName(char* sub_name) {
    if (sub_name == NULL) {
        err_printf("Input err, sub name ptr is NULL.\n");
        return -1;
    }
    
    snprintf(sub_name, MAX_TEMPLATE_NAME_LEN, "%s", sub_template_name_.c_str());
    return 0;
}

void WorkflowMgr::SetTaskTotalTime(u_int32_t time) {
    total_time_ = time;
}

u_int32_t WorkflowMgr::GetTaskTotalTime() {
    return total_time_;
}

long WorkflowMgr::GetTaskUsedTime() {
    timeval t;
    long used_time = 0;

    if (template_name_.empty()) {
        return 0;
    }

    gettimeofday(&t, NULL);
    used_time = (t.tv_sec - start_time_.tv_sec) + (t.tv_usec - start_time_.tv_usec) / 1000000;
    return used_time;
}

int WorkflowMgr::GetCurrentCmdInfo(char* info) {
    if (info == NULL) {
        err_printf("Input err, info ptr is NULL.\n");
        return -1;
    }

    if (cmd_que_.empty()) {
        //debuge_printf("Cmd queue is empty.\n");
        return -1;
    }

    snprintf(info, SLAVE_CMD_DESC_LEN, "%s", cmd_que_.front().cmd_info);
    return 0;
}

int WorkflowMgr::SetRealTimeCmdNo() {
    if (cmd_que_.empty()) {
        err_printf("Cmd queue is empty, cannot set realtime cmd no.\n");
        return -1;
    }

    time_t now = time(0);
    tm* ptime = localtime(&now);
    char time_str[DATATIME_LEN] = {0};
    
    snprintf(time_str, sizeof(time_str), "%04d_%02d_%02d_%02d_%02d_%02d", 
		(1900 + ptime->tm_year), (ptime->tm_mon + 1), ptime->tm_mday, ptime->tm_hour, ptime->tm_min, ptime->tm_sec);
    snprintf(cmd_que_[0].cmd_no_realtime, SLAVE_CMD_DESC_LEN, "%s|%s", cmd_que_[0].cmd_no, time_str);

    return 0;
}

void WorkflowMgr::InitCmdQueue() {
    u_int32_t i = current_phase_step_;
    u_int32_t j = 0;
    u_int32_t cmd_idx = 0;
    vector<string> substrs;
    string template_name_first;

    for (; i < action_que_.size(); i++) {
        SlaveCtrlCmd cmd = {0};
        cmd.retry_cnt = RETRY_NUM;
        cmd.cmd_id = ++cmd_idx;        
        cmd.action_hex_num = action_que_[i].action_hex_num;
        for (j = 0; j < cmd.action_hex_num; j++) {
            snprintf(cmd.action_hex[j], SLAVE_CMD_HEX_LEN, "%s", action_que_[i].action_hex[j]);
        }
        snprintf(cmd.cmd_type, sizeof(cmd.cmd_type), "%s", action_que_[i].name);
        snprintf(cmd.cmd_no, sizeof(cmd.cmd_no), "%s|%02d|%04d", sub_template_name_.c_str(), current_phase_, i+1);
        snprintf(cmd.cmd_info, sizeof(cmd.cmd_info), "%s", action_que_[i].desc);
        cmd_que_.push_back(cmd);
    }
}

int WorkflowMgr::CmdEnQueue(SlaveCtrlCmd* cmd) {
    if (cmd == NULL) {
        err_printf("Input err, cmd ptr is NULL.\n");
        return -1;
    }

    SlaveCtrlCmd cmd_t = {0};
    memcpy(&cmd_t, cmd, sizeof(SlaveCtrlCmd));
    cmd_que_.push_back(cmd_t);

    return 0;
}

int WorkflowMgr::GetCmdQueueFront(SlaveCtrlCmd* cmd) {
    if (cmd == NULL) {
        err_printf("Input err, cmd ptr is NULL.\n");
        return -1;
    }

    if (cmd_que_.empty()) {
        //err_printf("Cmd queue is empty.\n");
        return -1;
    }

    memcpy(cmd, &cmd_que_.front(), sizeof(SlaveCtrlCmd));
    return 0;
}

int WorkflowMgr::GetCmdQueueSize() {
    return cmd_que_.size();
}

int WorkflowMgr::CmdDeQueue() {
    if (cmd_que_.empty()) {
        err_printf("Cmd queue is empty, cannot dequeue.\n");
        return -1;
    }

    cmd_que_.erase(cmd_que_.begin());
    return 0;
}

int WorkflowMgr::GetActionQueueItem(ActionHex* action, u_int32_t id) {
    if (action == NULL) {
        err_printf("Input err, action ptr is NULL.\n");
        return -1;
    }

    int que_size = action_que_.size();
    if (id > que_size) {
        err_printf("Invalid get id, id:%d is greater than action queue_size:%d.\n", id, que_size);
        return -1;
    }

    memcpy(action, &action_que_[id-1], sizeof(ActionHex));
    return 0;
}

int WorkflowMgr::ActionEnQueue(ActionHex* action) {
    if (action == NULL) {
        err_printf("Input err, cmd ptr is NULL.\n");
        return -1;
    }

    ActionHex action_t = {0};
    memcpy(&action_t, action, sizeof(ActionHex));
    total_step_++;
    action_t.id = total_step_;
    action_que_.push_back(action_t);

    return total_step_;
}

int WorkflowMgr::GetActionQueueSize() {
    return action_que_.size();
}

void WorkflowMgr::DeinitWorkflowMgr() {
    if (!action_que_.empty()) {
        action_que_.clear();
    }

    if (!cmd_que_.empty()) {
        cmd_que_.clear();
    }

    if (!template_name_.empty()) {
        template_name_.clear();
    }
    
    if (!sub_template_name_.empty()) {
        sub_template_name_.clear();
    }

    current_phase_ = 0;
    current_phase_step_ = 0;

    total_time_ = 0;
    start_time_.tv_sec = 0;
    start_time_.tv_usec = 0;

    total_step_ = 0;
    last_heat_step_idx_ = 0;

    delete instance;
    instance = NULL;
}

WorkflowMgr::~WorkflowMgr() {
    if (!action_que_.empty()) {
        action_que_.clear();
    }

    if (!cmd_que_.empty()) {
        cmd_que_.clear();
    }

    if (!template_name_.empty()) {
        template_name_.clear();
    }
    
    if (!sub_template_name_.empty()) {
        sub_template_name_.clear();
    }
    
    current_phase_ = 0;
    current_phase_step_ = 0;

    total_time_ = 0;
    start_time_.tv_sec = 0;
    start_time_.tv_usec = 0;

    total_step_ = 0;
    last_heat_step_idx_ = 0;
}
