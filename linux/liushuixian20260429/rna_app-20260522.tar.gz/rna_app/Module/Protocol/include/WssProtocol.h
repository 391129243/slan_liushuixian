#ifndef __WSS_PROTOCOL_H__
#define __WSS_PROTOCOL_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <sys/types.h>
#include "Common.h"
#include "UartProtocol.h"
#include "cJSON.h"
#include "ConfLocal.h"
#include "md5.h"

#define CMD_TYPE_QUERY_DEVICE "QueryDevice"
#define CMD_TYPE_QUERY_DEVICE_REPLY "QueryDeviceReply"
#define CMD_TYPE_HEART_BEAT "HeartBeat"
#define CMD_TYPE_HEART_BEAT_REPLY "HeartBeatReply"
#define CMD_TYPE_ALARM_STATUS_REPORT "RNAStatus"
#define CMD_TYPE_RNA_REQ "RNAReq"
#define CMD_TYPE_RNA_ACK "RNAAck"
#define CMD_TYPE_RNA_STOP "RNAStop"
#define CMD_TYPE_RNA_STOP_ACK "RNAFinishAck"
#define CMD_TYPE_RNA_RUNNING_STATUS_REPORT "RNARunningStatus"
#define CMD_TYPE_RNA_DONE_STATUS "RNAFinish"
#define CMD_TYPE_RNA_DONE_STATUS_REPLY "RNAFinnishAck"
#define CMD_TYPE_RNA_LOG_REPORT "RNALog"
#define CMD_TYPE_UPGRADE "Upgrade"
#define CMD_TYPE_UPGRADE_ACK "UpgradeAck"
#define CMD_TYPE_UPGRADE_DONE_STATUS "UpgradeFinish"
#define CMD_TYPE_SET_LOG_LEVER "SetLogLevel"
#define CMD_TYPE_SET_LOG_LEVER_REPLY "SetLogLevelReply"
#define CMD_TYPE_UPDATE_CONFIG "UpdateConfig"
#define CMD_TYPE_UPDATE_CONFIG_REPLY "UpdateConfigReply"
#define CMD_TYPE_FACTORY_RESET "FactoryReset"
#define CMD_TYPE_FACTORY_RESET_REPLY "FactoryResetReply"

#define ACTION_LOOPSTART_FLAG "loopstart"
#define ACTION_LOOPEND_FLAG "loopend"

#define WSS_BINARY_HEADER_FLAG 0x5AA5FCFF

typedef struct sWssHeader {
    char type[WSS_CMD_TYPE_LEN];
    char device_id[DEVICE_ID_LEN];
    u_int32_t seq_id;
    u_int32_t desc_data_len;
} WssHeader;

typedef struct sWssBinaryHeader {
    u_int32_t header_flag;
    u_int32_t desc_data_len;
} WssBinaryHeader;

typedef struct sRNATaskInfo {
    char template_name[MAX_TEMPLATE_NAME_LEN];
    u_int8_t current_phase;
    u_int32_t current_phase_step;
    u_int32_t total_time;
    u_int32_t seq_id;
    pthread_t workflow_thread_id;
    char batch_id[TASK_ID_LEN];
} RNATaskInfo;

typedef struct sActionHex {
    u_int32_t id;
    char name[SLAVE_CTRL_CMD_LEN];
    char action_hex[MAX_SLAVE_CMD_HEX_NUM][SLAVE_CMD_HEX_LEN];
    u_int8_t action_hex_num;
    u_int8_t sleep;
    u_int16_t loop;
    char no[SLAVE_CMD_DESC_LEN];
    char desc[SLAVE_CMD_DESC_LEN];
    double params[MAX_SLAVE_CTRL_PARAM_NUM];
    bool is_selected;
} ActionHex;

typedef struct sRNAAck {
    char status[SLAVE_STATUS_LEN];
    char alarm[SLAVE_ALARM_LEN];
} RNAAck;

typedef struct sRNARunningStatus {
    char template_name[MAX_TEMPLATE_NAME_LEN];
    char status[SLAVE_STATUS_LEN];
    u_int32_t left_time;
    u_int32_t total_time;
    int degree;
    char alarm[SLAVE_ALARM_LEN];
    char cmd_no[SLAVE_CMD_DESC_LEN];
    char motor_id[SLAVE_MOTOR_ID_LEN];
    char info[SLAVE_CMD_DESC_LEN];
    char linux_status[SLAVE_STATUS_LEN];
    char linux_alarm[SLAVE_ALARM_LEN];
} RNARunningStatus;

typedef struct sRNAStatus {
    char template_name[MAX_TEMPLATE_NAME_LEN];
    char status[SLAVE_STATUS_LEN];
    int degree;
    char alarm[SLAVE_ALARM_LEN];
    char cmd_no[SLAVE_CMD_DESC_LEN];
    char motor_id[SLAVE_MOTOR_ID_LEN];
    char info[SLAVE_CMD_DESC_LEN];
    char linux_status[SLAVE_STATUS_LEN];
    char linux_alarm[SLAVE_ALARM_LEN];
} RNAStatus;

typedef struct sRNADoneStatus {
    char template_name[MAX_TEMPLATE_NAME_LEN];
    char status[SLAVE_STATUS_LEN];
    char alarm[SLAVE_ALARM_LEN];
    char info[SLAVE_CMD_DESC_LEN];
} RNADoneStatus;

typedef struct sUpgradeDescInfo {
    u_int64_t file_size;
    char md5[MD5_STR_LEN];
    char file_name[MAX_FILE_NAME_LEN];
    char version[VERSION_LEN];
} UpgradeDescInfo;

typedef struct sUpgradeDoneStatus {
    char status[SLAVE_STATUS_LEN];
    char alarm[SLAVE_CMD_DESC_LEN];
} UpgradeDoneStatus;

typedef enum eUpgradeStatus {
    UPGRADE_STATUS_SAME_VERSION,
    UPGRADE_STATUS_SUCCESS,
    UPGRADE_STATUS_VERSION_FILE_UNZIP_FAILED,
    UPGRADE_STATUS_VERSION_FILE_BACKUP_FAILED,
    UPGRADE_STATUS_RNA_VERSION_UPDATE_FAILED,
    UPGRADE_STATUS_PCR_VERSION_UPDATE_FAILED
}UpgradeStatus;

typedef enum eSetLogLevelStatus {
    SET_LOG_LEVEL_OK,
    SET_LOG_LEVEL_PARAM_INVALID,
    SET_LOG_LEVEL_JSON_ERR
} SetLogLevelStatus;

int SetLocalCfg(LocalCfg* cfg);

cJSON* WssDataHeaderParse(WssHeader* header, char* data);

cJSON* WssBinaryDataHeaderParse(WssHeader* header, char* data);

//pack protocol
u_int8_t* PackQueryDeviceReply(u_int32_t seq_id);

u_int8_t* PackHeartBeatReply(u_int32_t seq_id);

u_int8_t* PackRNAStatusReport(RNAStatus* status);

u_int8_t* PackRNAAckReport(u_int32_t seq_id, RNAAck* ack);

u_int8_t* PackRNAFinishAckReport(u_int32_t seq_id, RNAAck* ack);

u_int8_t* PackRNARunningStatusReport(RNARunningStatus* running_status);

u_int8_t* PackRNADoneStatusReport(u_int32_t seq_id, RNADoneStatus* done_status);

u_int8_t* PackRNALogReport(char* file_name, unsigned long* data_len);

u_int8_t* PackUpgradeAckReport(u_int32_t seq_id, RNAAck* ack);

u_int8_t* PackUpgradeDoneReport(u_int32_t seq_id, UpgradeDoneStatus* status);

u_int8_t* PackSetLogLevelReply(u_int32_t seq_id, u_int8_t status);

u_int8_t* PackUpdateCfgReply(u_int32_t seq_id, RNAAck* status);

u_int8_t* PackFactoryResetReply(u_int32_t seq_id, RNAAck* status);

//parse protocol
int ParseActionHex(cJSON* json, ActionHex* action);

int ParseUpgradeDescInfo(cJSON* root_json, UpgradeDescInfo* desc_info);

int ParseUpgradeVersionFile(char* data, UpgradeDescInfo* desc_info);

#ifdef __cplusplus
}
#endif

#endif