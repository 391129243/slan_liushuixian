package com.hongshi.slandemo;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.ActivityCompat;

import java.util.ArrayList;

public class PermissionUtils {

    /**
     * 检查权限，返回被拒绝的权限列表
     */
    public static ArrayList<String> checkPermissions(Activity activity, String[] permissions) {
        if (activity == null) {
            throw new NullPointerException("activity can't be null");
        }

        ArrayList<String> deniedPermissions = new ArrayList<>();

        // Android 6.0 以下不需要运行时权限
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return deniedPermissions;
        }

        // 检查每个权限
        for (String permission : permissions) {
            if (activity.checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                deniedPermissions.add(permission);
            }
        }

        return deniedPermissions;
    }

    /**
     * 请求权限
     */
    public static void requestPermission(Activity activity, String[] permissions, int requestCode) {
        if (activity == null) {
            throw new NullPointerException("activity can't be null");
        }

        ActivityCompat.requestPermissions(activity, permissions, requestCode);
    }
}
