#include "WorkflowMgr.h"
#include "WorkflowMgrWrapper.h"

int InitWorkflowMgr(u_int32_t seq_id, char* template_name, u_int8_t current_phase, u_int32_t current_phase_step) {
    return WorkflowMgr::GetInstance().InitWorkflowMgr(seq_id, template_name, current_phase, current_phase_step);
}

void SetCurrentPhase(u_int8_t current_phase) {
    WorkflowMgr::GetInstance().SetCurrentPhase(current_phase);
}

void SetCurrentPhaseStep(u_int32_t current_phase_step) {
    WorkflowMgr::GetInstance().SetCurrentPhaseStep(current_phase_step);
}

void SetLastHeatStepIdx(u_int32_t step_idx) {
    WorkflowMgr::GetInstance().SetLastHeatStepIdx(step_idx);
}

u_int32_t GetSeqId() {
    return WorkflowMgr::GetInstance().GetSeqId();
}

u_int32_t GetLastHeatStepIdx() {
    return WorkflowMgr::GetInstance().GetLastHeatStepIdx();
}

int GetTemplateName(char* name) {
    WorkflowMgr::GetInstance().GetTemplateName(name);
}

int GetSubTemplateName(char* sub_name) {
    WorkflowMgr::GetInstance().GetSubTemplateName(sub_name);
}

void SetTaskTotalTime(u_int32_t time) {
    WorkflowMgr::GetInstance().SetTaskTotalTime(time);
}

u_int32_t GetTaskTotalTime() {
    return WorkflowMgr::GetInstance().GetTaskTotalTime();
}

long GetTaskUsedTime() {
    return WorkflowMgr::GetInstance().GetTaskUsedTime();
}

int GetCurrentCmdInfo(char* info) {
    return WorkflowMgr::GetInstance().GetCurrentCmdInfo(info);
}

int SetRealTimeCmdNo() {
    return WorkflowMgr::GetInstance().SetRealTimeCmdNo();
}

void InitCmdQueue() {
    WorkflowMgr::GetInstance().InitCmdQueue();
}

int CmdEnQueue(SlaveCtrlCmd* cmd) {
    return WorkflowMgr::GetInstance().CmdEnQueue(cmd);
}

int GetCmdQueueFront(SlaveCtrlCmd* cmd) {
    return WorkflowMgr::GetInstance().GetCmdQueueFront(cmd);
}

int GetCmdQueueSize() {
    return WorkflowMgr::GetInstance().GetCmdQueueSize();
}

int CmdDeQueue() {
    return WorkflowMgr::GetInstance().CmdDeQueue();
}

int GetActionQueueItem(ActionHex* action, u_int32_t id) {
    return WorkflowMgr::GetInstance().GetActionQueueItem(action, id);
}

int ActionEnQueue(ActionHex* action) {
    return WorkflowMgr::GetInstance().ActionEnQueue(action);
}

int GetActionQueueSize() {
    return WorkflowMgr::GetInstance().GetActionQueueSize();
}
    
void DeinitWorkflowMgr() {
    WorkflowMgr::GetInstance().DeinitWorkflowMgr();
}