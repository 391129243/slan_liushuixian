package com.hongshi.slandemo;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hongshi.slansdk.model.ServiceParams;
import com.hongshi.slansdk.model.device.Device;
import com.hongshi.slansdk.service.SLANService;
import com.hongshi.slansdk.slanenum.ConnectType;
import com.hongshi.slansdk.slanenum.DeviceType;
import android.Manifest;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    SLANService slanService = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TextView textView = findViewById(R.id.serial);
        Button button = findViewById(R.id.connect);

        checkStoragePermission();
        ServiceParams params = new ServiceParams();
        params.setConnectType(ConnectType.USB);
        params.setDeviceType(DeviceType.SLAN_48S);
        params.setDebug(true);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(slanService==null)
                {
                    slanService = new SLANService(MainActivity.this, params);
                }
                ArrayList<Device> devices= slanService.getDevice(true);

                if(!devices.isEmpty())
                {
                    String serialNo= devices.get(0).getSerialNo();
                    textView.setText(serialNo);
                    showToast("连接成功");
                }
                else
                {
                    textView.setText("");
                    showToast("连接失败");
                }
            }
        });
    }

    private void showToast(String msg)
    {
        Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
    }

    private void checkStoragePermission() {
        // 只检查存储权限
        String[] permissions = new String[]{
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
        };

        ArrayList<String> deniedPermissions = PermissionUtils.checkPermissions(this, permissions);

        if (!deniedPermissions.isEmpty()) {
            String[] deniedPermissionArray = deniedPermissions.toArray(new String[0]);
            PermissionUtils.requestPermission(this, deniedPermissionArray, 9);
        } else {

        }
    }

    // 权限请求结果回调
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 9) {
            for (int i = 0; i < permissions.length; i++) {
                if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                   // Log.d("Permission", "权限已授予: " + permissions[i]);
                } else {
                    //Log.d("Permission", "权限被拒绝: " + permissions[i]);
                }
            }
        }
    }
}


