# rna_app
# How to build project
cd rna_app
./build.sh

# How to run rna_app
cd rna_app/build/output/config
sh install.sh
cd rna_app/build/output/
cp rna_app_*.tar.gz /home/rna_app/apprun
# modify local config and server config
vi /config/local_config/local_cfg.json
vi /config/server_config/srv_cfg.json
cd rna_app/build/output/config/local_config/
sh rc.local
