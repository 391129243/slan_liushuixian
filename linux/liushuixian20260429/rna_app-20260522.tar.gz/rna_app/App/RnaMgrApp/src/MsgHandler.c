#include "MsgWrapper.h"
#include "WssProtocol.h"
#include "Wss.h"
#include "Logger.h"
#include "System.h"
#include "CmdHandler.h"

int HandleReportLogFileMsg(MsgInfo* msg_info) {
    u_int8_t* json_str = NULL;
    int ret = 0;
    unsigned long data_len = 0;
    char file_name[MAX_FILE_NAME_LEN] = {0};

    warn_printf("====recv send log msg===.\n");
    
    if (msg_info == NULL || msg_info->data == NULL) {
        err_printf("Input err, msg data is NULL.\n");
        return -1;
    }

    json_str = PackRNALogReport(msg_info->data, &data_len);
    if (json_str == NULL) {
        err_printf("Report log file:%s failed, json pack err.\n", msg_info->data);
        return -1;
    }

    ret = WssSendData(json_str, data_len, WEBSOCKET_OP_BINARY);
    if (ret != 0) {
        err_printf("Report log file:%s failed, wss send err.\n", msg_info->data);
    } else {
        warn_printf("====Report log file:%s success.\n", msg_info->data);
        snprintf(file_name, sizeof(file_name), "%s_bk", msg_info->data);
        ret = RenameFile(msg_info->data, file_name);
    }

    free(json_str);
    return ret;
}

int ReportAutoStartLogFile() {
    u_int8_t* json_str = NULL;
    int ret = 0;
    char file_name[MAX_FILE_NAME_LEN] = {0};
    time_t timep;
	struct tm *p = NULL;
	char time_str[128] = {0};
    unsigned long data_len = 0;

	timep = time(NULL);   
	p = localtime(&timep);
	sprintf(time_str, "%04d_%02d_%02d_%02d_%02d_%02d", 
		(1900 + p->tm_year), (p->tm_mon + 1), p->tm_mday, p->tm_hour, p->tm_min, p->tm_sec);
    snprintf(file_name, sizeof(file_name), "/logs/auto_start_%s.log", time_str);
    RenameFile("/logs/auto_start.log", file_name);

    json_str = PackRNALogReport(file_name, &data_len);
    if (json_str == NULL) {
        err_printf("Report auto start log file failed, json pack err.\n");
        return -1;
    }

    ret = WssSendData(json_str, data_len, WEBSOCKET_OP_BINARY);
    if (ret != 0) {
        err_printf("Report auto start log file failed, wss send err.\n");
    } else {
        warn_printf("====Report auto start log file success.\n");
        RemoveFile(file_name);
    }
    
    free(json_str);
    return ret;
}

int HandleUartDisConnectMsg(MsgInfo* msg_info) {
    RNARunningStatus running_status = {0};
    RNAStatus status = {0};
    SlaveCtrlCmd cmd = {0};
    int ret = 0;
    clock_t t;
    char* json_str = NULL;

    snprintf(g_status.linux_status, sizeof(g_status.linux_status), "error");

    snprintf(status.template_name, sizeof(status.template_name), "%s", g_status.template_name);
    snprintf(status.status, sizeof(status.status), "%s", g_status.status);
    snprintf(status.cmd_no, sizeof(status.cmd_no), "%s", g_status.cmd_no);
    snprintf(status.alarm, sizeof(status.alarm), "%s", g_status.alarm);
    status.degree = g_status.degree;
    snprintf(status.info, sizeof(status.info), "%s", g_status.info);
    snprintf(status.linux_status, sizeof(status.linux_status), "%s", g_status.linux_status);
    snprintf(status.linux_alarm, sizeof(status.linux_alarm), "uart disconnect");

    if (GetActionQueueSize() > 0) {
        GetCmdQueueFront(&cmd);
        snprintf(running_status.template_name, sizeof(running_status.template_name), "%s", status.template_name);
        snprintf(running_status.status, sizeof(running_status.status), "%s", g_status.status);
        snprintf(running_status.cmd_no, sizeof(running_status.cmd_no), "%s", cmd.cmd_no);
        snprintf(running_status.alarm, sizeof(running_status.alarm), "%s", g_status.alarm);
        snprintf(running_status.info, sizeof(running_status.info), "%s", cmd.cmd_info);
        snprintf(running_status.linux_status, sizeof(running_status.linux_status), "%s", g_status.linux_status);
        snprintf(running_status.linux_alarm, sizeof(running_status.linux_alarm), "uart disconnect");
        running_status.degree = g_status.degree;
        running_status.total_time = GetTaskTotalTime();
        if (running_status.total_time > 0) {
            unsigned long used_time = GetTaskUsedTime();
            if (running_status.total_time > used_time) {
                running_status.left_time = running_status.total_time - used_time;
            } else {
                running_status.left_time = 0;
            }    
        }

        json_str = PackRNARunningStatusReport(&running_status);
        if (json_str == NULL) {
            err_printf("Report rna running status failed, json pack err.\n");
            return -1;
        }

        ret = WssSendData(json_str, strlen(json_str), WEBSOCKET_OP_TEXT);
        if (ret != 0) {
            err_printf("Report rna running status failed, wss send err.\n");
        }
        
        free(json_str);
    } else {
        json_str = PackRNAStatusReport(&status);
        if (json_str == NULL) {
            err_printf("Report rna status failed, json pack err.\n");
            return -1;
        }

        ret = WssSendData(json_str, strlen(json_str), WEBSOCKET_OP_TEXT);
        if (ret != 0) {
            err_printf("Report rna status failed, wss send err.\n");
        }
        free(json_str);
    }

    return ret;
}

int HandleUartConnectedMsg(MsgInfo* msg_info) {
    RNARunningStatus running_status = {0};
    RNAStatus status = {0};
    SlaveCtrlCmd cmd = {0};
    int ret = 0;
    clock_t t;
    char* json_str = NULL;

    snprintf(status.template_name, sizeof(status.template_name), "%s", g_status.template_name);
    snprintf(status.status, sizeof(status.status), "%s", g_status.status);
    snprintf(status.cmd_no, sizeof(status.cmd_no), "%s", g_status.cmd_no);
    snprintf(status.alarm, sizeof(status.alarm), "%s", g_status.alarm);
    status.degree = g_status.degree;
    snprintf(status.info, sizeof(status.info), "%s", g_status.info);
    snprintf(status.linux_alarm, sizeof(status.linux_alarm), "");

    if (GetActionQueueSize() > 0) {
        snprintf(g_status.linux_status, sizeof(g_status.linux_status), "running");

        GetCmdQueueFront(&cmd);
        snprintf(running_status.template_name, sizeof(running_status.template_name), "%s", status.template_name);
        snprintf(running_status.status, sizeof(running_status.status), "%s", g_status.status);
        snprintf(running_status.cmd_no, sizeof(running_status.cmd_no), "%s", cmd.cmd_no);
        snprintf(running_status.alarm, sizeof(running_status.alarm), "%s", g_status.alarm);
        snprintf(running_status.info, sizeof(running_status.info), "%s", cmd.cmd_info);
        snprintf(running_status.linux_status, sizeof(running_status.linux_status), "%s", g_status.linux_status);
        snprintf(running_status.linux_alarm, sizeof(running_status.linux_alarm), "");
        running_status.degree = g_status.degree;
        running_status.total_time = GetTaskTotalTime();
        if (running_status.total_time > 0) {
            unsigned long used_time = GetTaskUsedTime();
            if (running_status.total_time > used_time) {
                running_status.left_time = running_status.total_time - used_time;
            } else {
                running_status.left_time = 0;
            }    
        }

        json_str = PackRNARunningStatusReport(&running_status);
        if (json_str == NULL) {
            err_printf("Report rna running status failed, json pack err.\n");
            return -1;
        }

        ret = WssSendData(json_str, strlen(json_str), WEBSOCKET_OP_TEXT);
        if (ret != 0) {
            err_printf("Report rna running status failed, wss send err.\n");
        }
        
        free(json_str);
    } else {
        snprintf(g_status.linux_status, sizeof(g_status.linux_status), "free");
        snprintf(status.linux_status, sizeof(status.linux_status), "%s", g_status.linux_status);
        
        json_str = PackRNAStatusReport(&status);
        if (json_str == NULL) {
            err_printf("Report rna status failed, json pack err.\n");
            return -1;
        }

        ret = WssSendData(json_str, strlen(json_str), WEBSOCKET_OP_TEXT);
        if (ret != 0) {
            err_printf("Report rna status failed, wss send err.\n");
        }
        free(json_str);
    }

    return ret;
}


int HandleUpgradeStatusMsg(MsgInfo* msg_info) {
    UpgradeDoneStatus status = {0};

    if (msg_info == NULL) {
        err_printf("Input err, msg_info ptr is NULL.\n");
        return -1;
    }

    switch (msg_info->header.result)
    {
    case UPGRADE_STATUS_SAME_VERSION:
        snprintf(status.status, sizeof(status.status), "ok");
        snprintf(status.alarm, sizeof(status.alarm), "Version is same as old version");
        break;

    case UPGRADE_STATUS_SUCCESS:
        snprintf(status.status, sizeof(status.status), "ok");
        break;

    case UPGRADE_STATUS_VERSION_FILE_UNZIP_FAILED:
        snprintf(status.status, sizeof(status.status), "error");
        snprintf(status.alarm, sizeof(status.alarm), "Version file unzip err");
        break;

    case UPGRADE_STATUS_VERSION_FILE_BACKUP_FAILED:
        snprintf(status.status, sizeof(status.status), "error");
        snprintf(status.alarm, sizeof(status.alarm), "Version file backup err");
        break;

    case UPGRADE_STATUS_RNA_VERSION_UPDATE_FAILED:
    case UPGRADE_STATUS_PCR_VERSION_UPDATE_FAILED:
        snprintf(status.status, sizeof(status.status), "error");
        snprintf(status.alarm, sizeof(status.alarm), "Version file update err");
        break;

    default:
        break;
    }

    UpgradeDoneStatusReport(msg_info->header.handle_id, &status);

    if (msg_info->header.result == UPGRADE_STATUS_SUCCESS) {
        warn_printf("====Update success, system will reboot after 5s====\n");
	    sleep(5);
	    system("sync;reboot");
    }

    return 0;
}
