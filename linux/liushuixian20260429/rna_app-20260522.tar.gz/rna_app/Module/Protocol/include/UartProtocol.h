#ifndef __UART_PROTOCOL_H__
#define __UART_PROTOCOL_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <sys/types.h>
#include "Common.h"

#define SLAVE_CMD_TYPE_HEAT "heat"
#define SLAVE_CMD_TYPE_MOVE "move"

#define SLAVE_CMD_STATUS_RUNNING "running"
#define SLAVE_CMD_STATUS_DONE "done"
#define SLAVE_CMD_STATUS_ERROR "error"
#define SLAVE_CMD_STATUS_RECEIVED "MCUreceived"

#define SLAVE_ALARM_DISCONNECTED "disconnected"
#define SLAVE_ALARM_LOCKED "locked"
#define SLAVE_ALARM_OVERHEATED "overheated"
#define SLAVE_ALARM_CRC_ERR "crc"

#define RETRY_NUM 3
#define SLAVE_CMD_HEAT_TIMEOUT 60 //time unit:s
#define SLAVE_CMD_RNA_TIMEOUT 90 //time unit:s
#define HEARTBEAT_INTERVAL 2*1000 //time unit:ms

#pragma pack(1)
typedef struct sUartHeader {
    u_int8_t header_flag_1;
    u_int8_t header_flag_2;
    u_int16_t data_len;
    u_int8_t func_id;
} UartHeader;

typedef struct sUartTailer {
    u_int16_t crc;
    u_int8_t tailer_flag_1;
    u_int8_t tailer_flag_2;
    u_int8_t tailer_flag_3;
} UartTailer;
#pragma pack()

typedef struct sSlaveCtrlCmd {
    u_int32_t cmd_id;
    char cmd_type[SLAVE_CTRL_CMD_LEN];
    char action_hex[MAX_SLAVE_CMD_HEX_NUM][SLAVE_CMD_HEX_LEN];
    u_int8_t action_hex_num;
    u_int8_t retry_cnt;
    char cmd_no[SLAVE_CMD_DESC_LEN];
    char cmd_no_realtime[SLAVE_CMD_DESC_LEN];
    char cmd_info[SLAVE_CMD_DESC_LEN];
} SlaveCtrlCmd;

typedef struct sSlaveStatusParam {
    u_int32_t cmd_id;
    char cmd_no[SLAVE_CMD_DESC_LEN];
    char status[SLAVE_STATUS_LEN];
    char alarm[SLAVE_ALARM_LEN]; 
    char motor_id[SLAVE_MOTOR_ID_LEN];
    int degree;
} SlaveStatusParam;

typedef struct sSlaveCmdStatusParam {
    u_int32_t cmd_id;
    char cmd_no[SLAVE_CMD_DESC_LEN];
    char status[SLAVE_STATUS_LEN];    
    int degree;
} SlaveCmdStatusParam;

typedef struct sSlaveAlarmParam {
    u_int32_t cmd_id;
    char motor_id[SLAVE_MOTOR_ID_LEN];
    char status[SLAVE_STATUS_LEN];
    char alarm[SLAVE_ALARM_LEN];    
    int degree;
} SlaveAlarmParam;

typedef struct sSlaveCmdRspParam {
    u_int32_t cmd_id;
    char status[SLAVE_STATUS_LEN];
    char alarm[SLAVE_ALARM_LEN];    
} SlaveCmdRspParam;

u_int8_t* UartPacketWrapper(u_int8_t* data, u_int16_t data_len);

int UartPacketParse(UartHeader *header, u_int8_t* packet, u_int16_t packet_len);

//pack protocol
u_int8_t* PackSlaveCtrlCmd(SlaveCtrlCmd* cmd, int* cmd_data_len);

//parse protocol
int ParseSlaveStatusParam(u_int8_t* data, SlaveStatusParam* param);

int ParseSlaveCmdStatusParam(u_int8_t* data, SlaveCmdStatusParam* param);

int ParseSlaveAlarmParam(u_int8_t* data, SlaveAlarmParam* param);

int ParseSlaveCmdRspParam(u_int8_t* data, SlaveCmdRspParam* param);

#ifdef __cplusplus
}
#endif

#endif