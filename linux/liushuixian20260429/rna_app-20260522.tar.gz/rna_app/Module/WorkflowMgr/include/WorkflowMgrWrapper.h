#ifndef __WORKFLOW_MGR_H__WRAPPER_H__
#define __WORKFLOW_MGR_H__WRAPPER_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "cJSON.h"
#include "UartProtocol.h"

int InitWorkflowMgr(u_int32_t seq_id, char* template_name, u_int8_t current_phase, u_int32_t current_phase_step);

void SetCurrentPhase(u_int8_t current_phase);

void SetCurrentPhaseStep(u_int32_t current_phase_step);

void SetLastHeatStepIdx(u_int32_t step_idx);

u_int32_t GetSeqId();

u_int32_t GetLastHeatStepIdx();

int GetTemplateName(char* name);

int GetSubTemplateName(char* sub_name);

void SetTaskTotalTime(u_int32_t time);

u_int32_t GetTaskTotalTime();

long GetTaskUsedTime();

int GetCurrentCmdInfo(char* info);

int SetRealTimeCmdNo();

void InitCmdQueue();

int CmdEnQueue(SlaveCtrlCmd* cmd);

int GetCmdQueueFront(SlaveCtrlCmd* cmd);

int GetCmdQueueSize();

int CmdDeQueue();

int GetActionQueueItem(ActionHex* action, u_int32_t id);

int ActionEnQueue(ActionHex* action);

int GetActionQueueSize();
    
void DeinitWorkflowMgr();

#ifdef __cplusplus
};
#endif

#endif