#ifndef __WORKFLOW_MGR_H__
#define __WORKFLOW_MGR_H__

#include <sys/time.h>
#include <map>
#include <vector>
#include <string>
#include <set>

#include "cJSON.h"
#include "WssProtocol.h"
#include "UartProtocol.h"

using namespace std;

class WorkflowMgr {
public:
    static WorkflowMgr& GetInstance();

    int InitWorkflowMgr(u_int32_t seq_id, char* template_name, u_int8_t current_phase, u_int32_t current_phase_step);

    void SetCurrentPhase(u_int8_t current_phase);

    void SetCurrentPhaseStep(u_int32_t current_phase_step);

    void SetLastHeatStepIdx(u_int32_t step_idx);

    u_int32_t GetSeqId();

    u_int32_t GetLastHeatStepIdx();

    int GetTemplateName(char* name);

    int GetSubTemplateName(char* sub_name);

    void SetTaskTotalTime(u_int32_t time);

    u_int32_t GetTaskTotalTime();

    long GetTaskUsedTime();

    int GetCurrentCmdInfo(char* info);

    int SetRealTimeCmdNo();

    void InitCmdQueue();

    int CmdEnQueue(SlaveCtrlCmd* cmd);

    int GetCmdQueueFront(SlaveCtrlCmd* cmd);

    int GetCmdQueueSize();

    int CmdDeQueue();

    int GetActionQueueItem(ActionHex* action, u_int32_t id);

    int ActionEnQueue(ActionHex* action);

    int GetActionQueueSize();
    
    void DeinitWorkflowMgr();
private:
    static WorkflowMgr* instance;
    WorkflowMgr() {};
    ~WorkflowMgr();

    u_int32_t seq_id_;
    string template_name_;
    string sub_template_name_;
    u_int8_t current_phase_;
    u_int32_t current_phase_step_;

    u_int32_t total_time_;
    timeval start_time_;

    u_int32_t total_step_;
    u_int32_t last_heat_step_idx_;

    vector<ActionHex> action_que_;
    vector<SlaveCtrlCmd> cmd_que_;
};


#endif
