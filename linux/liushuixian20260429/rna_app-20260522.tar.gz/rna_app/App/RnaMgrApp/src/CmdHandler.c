#include <sys/time.h>

#include "Logger.h"
#include "WssProtocol.h"
#include "MsgWrapper.h"
#include "UartProtocol.h"
#include "Wss.h"
#include "WorkflowMgrWrapper.h"
#include "AsyncCond.h"
#include "ConfLocal.h"
#include "FileManager.h"
#include "Timer.h"

//static unsigned short ResetSystermTimeCnt = 720;
static u_int8_t s_time_syn_flag = 0;

static bool s_task_exist = false;
static AsyncCond s_cond = NULL;
static u_int8_t s_slave_cmd_status = 0;
RNAStatus g_status = {0};
static int8_t s_uart_status = -1;
static pthread_t s_report_rna_finish_status_thread_id = 0;
static PTimerMsgInfo s_report_rna_finish_status_timer_info = NULL;
static RNADoneStatus s_done_status = {0};
static int s_rna_finish_status_ack = 0;
static pthread_mutex_t s_lock;

void InitLock() {
    pthread_mutex_init(&s_lock, NULL);
}

void DestroyLock() {
    pthread_mutex_destroy(&s_lock);
}

void RNAStatusRegularReport(void* arg) {
    int ret = 0;
    char* json_str = NULL;

    if (s_uart_status == -1) {
        snprintf(g_status.status, sizeof(g_status.status), "error");
        snprintf(g_status.alarm, sizeof(g_status.alarm), "slave uart err");

        json_str = PackRNAStatusReport(&g_status);
        if (json_str == NULL) {
            err_printf("Report rna status:%s failed, json pack err.\n", g_status.status);
            return -1;
        }

        ret = WssSendData(json_str, strlen(json_str), WEBSOCKET_OP_TEXT);
        if (ret != 0) {
            err_printf("Report rna status:%s failed, wss send err, json:%s.\n", g_status.status, json_str);
        }
        free(json_str);
    }  
}

void StartStatusRegularReport() {
    SetMillisecondsTimer(HEARTBEAT_INTERVAL, RNAStatusRegularReport, &g_status);
}

int SlaveStatusHandler(u_int8_t* data) {
    SlaveStatusParam param = {0};
    RNARunningStatus running_status = {0};
    int ret = 0;
    clock_t t;
    char* json_str = NULL;

    if (data == NULL) {
        err_printf("Input err, data ptr is NULL.\n");
        return -1;
    }

    ret = ParseSlaveStatusParam(data, &param);
    if (ret != 0) {
        err_printf("Parse SlaveStatusParam err.\n");
        return -1;
    }

    s_uart_status = 1;
    snprintf(g_status.status, sizeof(g_status.status), "%s", param.status);
    snprintf(g_status.cmd_no, sizeof(g_status.cmd_no), "%s", param.cmd_no);
    snprintf(g_status.alarm, sizeof(g_status.alarm), "%s", param.alarm);
    snprintf(g_status.motor_id, sizeof(g_status.motor_id), "%s", param.motor_id);
    g_status.degree = param.degree;
    memset(g_status.template_name, 0, MAX_TEMPLATE_NAME_LEN);
    memset(g_status.info, 0, SLAVE_CMD_DESC_LEN);

    if (GetActionQueueSize() > 0) {
        GetTemplateName(g_status.template_name);
        GetCurrentCmdInfo(g_status.info);
        snprintf(running_status.template_name, sizeof(running_status.template_name), "%s", g_status.template_name);
        snprintf(running_status.status, sizeof(running_status.status), "%s", param.status);
        snprintf(running_status.cmd_no, sizeof(running_status.cmd_no), "%s", param.cmd_no);
        snprintf(running_status.alarm, sizeof(running_status.alarm), "%s", param.alarm);
        snprintf(running_status.motor_id, sizeof(running_status.motor_id), "%s", param.motor_id);
        snprintf(running_status.info, sizeof(running_status.info), "%s", g_status.info);
        snprintf(running_status.linux_status, sizeof(running_status.linux_status), "%s", g_status.linux_status);
        snprintf(running_status.linux_alarm, sizeof(running_status.linux_alarm), "%s", g_status.linux_alarm);
        running_status.degree = param.degree;
        running_status.total_time = GetTaskTotalTime();
        if (running_status.total_time > 0) {
            unsigned long used_time = GetTaskUsedTime();
            if (running_status.total_time > used_time) {
                running_status.left_time = running_status.total_time - used_time;
            } else {
                running_status.left_time = 0;
            }    
        }

        json_str = PackRNARunningStatusReport(&running_status);
        if (json_str == NULL) {
            err_printf("Report rna running status:%s failed, json pack err.\n", param.status);
            return -1;
        }

        ret = WssSendData(json_str, strlen(json_str), WEBSOCKET_OP_TEXT);
        if (ret != 0) {
            err_printf("Report rna running status:%s failed, wss send err.\n", param.status);
        }
        
        free(json_str);
    }

    json_str = PackRNAStatusReport(&g_status);
    if (json_str == NULL) {
        err_printf("Report rna status:%s failed, json pack err.\n", param.status);
        return -1;
    }

    ret = WssSendData(json_str, strlen(json_str), WEBSOCKET_OP_TEXT);
    if (ret != 0) {
        err_printf("Report rna status:%s failed, wss send err.\n", param.status);
    }
    free(json_str);
    snprintf(g_status.linux_alarm, sizeof(g_status.linux_alarm), "");

    return ret;
}

int SlaveCmdStatusHandler(u_int8_t* data) {
    SlaveCmdStatusParam param = {0};
    int ret = 0;

    if (data == NULL) {
        err_printf("Input err, data ptr is NULL.\n");
        return -1;
    }

    ret = ParseSlaveCmdStatusParam(data, &param);
    if (ret != 0) {
        err_printf("Parse SlaveCmdStatusParam err.\n");
        return -1;
    }

    if (strcmp(param.status, SLAVE_CMD_STATUS_DONE) == 0) {
        s_slave_cmd_status = 1;
    } else if (strcmp(param.status, SLAVE_CMD_STATUS_ERROR) == 0) {
        s_slave_cmd_status = 0;
    }

    if (s_cond) {
        SignalAsyncCond(s_cond, NULL, NULL);
    }
    
    return 0;
}

int SlaveAlarmHandler(u_int8_t* data) {
    SlaveAlarmParam param = {0};
    RNAStatus status = {0};
    int ret = 0;
    char* json_str = NULL;

    if (data == NULL) {
        err_printf("Input err, data ptr is NULL.\n");
        return -1;
    }

    ret = ParseSlaveAlarmParam(data, &param);
    if (ret != 0) {
        err_printf("Parse SlaveAlarmParam err.\n");
        return -1;
    }

    GetTemplateName(status.template_name);
    status.degree = param.degree;
    g_status.degree = param.degree;
    snprintf(status.status, sizeof(status.status), "%s", param.status);
    snprintf(status.alarm, sizeof(status.alarm), "%s", param.alarm);
    snprintf(status.motor_id, sizeof(status.motor_id), "%s", param.motor_id);
    snprintf(status.linux_status, sizeof(status.linux_status), "%s", g_status.linux_status);
    snprintf(status.linux_alarm, sizeof(status.linux_alarm), "%s", g_status.linux_alarm);

    json_str = PackRNAStatusReport(&status);
    if (json_str == NULL) {
        err_printf("Report alarm failed, json pack err.\n");
        return -1;
    }

    ret = WssSendData(json_str, strlen(json_str), WEBSOCKET_OP_TEXT);
    if (ret != 0) {
        err_printf("Report alarm:%s failed, wss send err.\n", param.alarm);
    }
    
    free(json_str);
    return ret;
}

int SlaveCmdRspHandler(u_int8_t* data) {
    SlaveCmdRspParam param = {0};
    int ret = 0;

    if (data == NULL) {
        err_printf("Input err, data ptr is NULL.\n");
        return -1;
    }

    ret = ParseSlaveCmdRspParam(data, &param);
    if (ret != 0) {
        err_printf("Parse SlaveCmdRspParam err.\n");
        return -1;
    }

    if (strcmp(param.status, SLAVE_CMD_STATUS_RECEIVED) == 0) {
        //todo: setting task manager status,waiting for cmd process done
    } else if (strcmp(param.status, SLAVE_CMD_STATUS_ERROR) == 0) {
        s_slave_cmd_status = 0;
        if (s_cond) {
            SignalAsyncCond(s_cond, NULL, NULL);
        }
    }

    return 0;
}

int UartPacketParseErrReport() {
    RNARunningStatus running_status = {0};
    RNAStatus status = {0};
    SlaveCtrlCmd cmd = {0};
    int ret = 0;
    clock_t t;
    char* json_str = NULL;

    snprintf(status.status, sizeof(status.status), "%s", g_status.status);
    snprintf(status.cmd_no, sizeof(status.cmd_no), "%s", g_status.cmd_no);
    snprintf(status.alarm, sizeof(status.alarm), "%s", g_status.alarm);
    snprintf(status.linux_status, sizeof(status.linux_status), "%s", g_status.linux_status);
    snprintf(status.linux_alarm, sizeof(status.linux_alarm), "uart data parse err");
    status.degree = g_status.degree;

    if (GetActionQueueSize() > 0) {
        GetCmdQueueFront(&cmd);
        GetTemplateName(status.template_name);
        snprintf(status.info, sizeof(status.info), "%s", cmd.cmd_info);
        
        snprintf(running_status.template_name, sizeof(running_status.template_name), "%s", status.template_name);
        snprintf(running_status.status, sizeof(running_status.status), "%s", g_status.status);
        snprintf(running_status.cmd_no, sizeof(running_status.cmd_no), "%s", cmd.cmd_no);
        snprintf(running_status.alarm, sizeof(running_status.alarm), "%s", g_status.alarm);
        snprintf(running_status.info, sizeof(running_status.info), "%s", cmd.cmd_info);
        snprintf(running_status.linux_status, sizeof(running_status.linux_status), "%s", g_status.linux_status);
        snprintf(running_status.linux_alarm, sizeof(running_status.linux_alarm), "uart data parse err");
        running_status.degree = g_status.degree;
        running_status.total_time = GetTaskTotalTime();
        if (running_status.total_time > 0) {
            unsigned long used_time = GetTaskUsedTime();
            if (running_status.total_time > used_time) {
                running_status.left_time = running_status.total_time - used_time;
            } else {
                running_status.left_time = 0;
            }    
        }

        json_str = PackRNARunningStatusReport(&running_status);
        if (json_str == NULL) {
            err_printf("Report rna running status failed, json pack err.\n");
            return -1;
        }

        ret = WssSendData(json_str, strlen(json_str), WEBSOCKET_OP_TEXT);
        if (ret != 0) {
            err_printf("Report rna running status failed, wss send err.\n");
        }
        
        free(json_str);
    } else {
        json_str = PackRNAStatusReport(&status);
        if (json_str == NULL) {
            err_printf("Report rna status failed, json pack err.\n");
            return -1;
        }

        ret = WssSendData(json_str, strlen(json_str), WEBSOCKET_OP_TEXT);
        if (ret != 0) {
            err_printf("Report rna status failed, wss send err.\n");
        }
        free(json_str);
    }

    return ret;
}

int UartPacketHandler(unsigned char *packet, unsigned int len) {
    int ret = 0;
    UartHeader header = {0};
    u_int8_t* data = NULL;
    u_int16_t data_len = 0;

    if (packet == NULL || len == 0) {
        err_printf("Input err, packet ptr is NULL or len is 0.\n");
        UartPacketParseErrReport();
        return -1;
    }

    ret = UartPacketParse(&header, packet, len);
    if (ret != 0) {
        err_printf("Packet is invalid, parse err.\n");
        UartPacketParseErrReport();
        return -1;
    } 

    data_len = ntohs(header.data_len);
    data = packet + sizeof(UartHeader);
    data[data_len] = '\0';

    warn_printf("Uart hander func_id:%x, data:%s.\n", header.func_id, data);
    
    switch (header.func_id) {
        case 0xA1:
            SlaveStatusHandler(data);
            break;

        case 0xA2:
            SlaveCmdStatusHandler(data);
            break;

        case 0xA3:
            SlaveAlarmHandler(data);
            break;

        case 0xA4:
            SlaveCmdRspHandler(data);
            break;

        default:
            break;
    }
    
    return 0;
}

void* RNADoneStatusReportTimerHandler(void* arg) {
    if (s_rna_finish_status_ack == 0) {
        RNADoneStatusReport(GetSeqId(), &s_done_status);
    }    
    return NULL;
}

int RNADoneStatusReport(u_int32_t seq_id, RNADoneStatus* status) {
    char* json_str = NULL;
    int ret = 0;

    if (status == NULL) {
        err_printf("Input err, status ptr is NULL.\n");
        return -1;
    }

    json_str = PackRNADoneStatusReport(seq_id, status);
    if (json_str == NULL) {
        err_printf("Report RNA done status failed, json packe err.\n");
        return -1;
    }
    ret = WssSendData(json_str, strlen(json_str), WEBSOCKET_OP_TEXT);
    if (ret != 0) {
        err_printf("Report RNA done status failed, wss send err.\n");
    } else {
        s_rna_finish_status_ack = 0;
    }

    free(json_str);
    if (s_report_rna_finish_status_timer_info == NULL) {
        s_report_rna_finish_status_timer_info = ResetMillisecondsTimer(1000, RNADoneStatusReportTimerHandler, NULL, &s_report_rna_finish_status_thread_id);
        pthread_detach(s_report_rna_finish_status_thread_id);
    }
    return ret;
}

int QueryDeviceHandler(WssHeader* header, cJSON* json) {
    int ret = 0;
    char* json_str = NULL;
    LocalCfg local_cfg = {0};
    cJSON* item_json = NULL;
    int position = 0;
    char device_id[DEVICE_ID_LEN] = {0};
    char device_type[DEVICE_ID_LEN] = {0};

    if (header == NULL) {
        err_printf("Input err, WssHeader ptr is NULL.\n");
        return -1;
    }

    item_json = cJSON_GetObjectItem(json, "Position");
    if (item_json == NULL) {
        err_printf("Json parse failed, get key[Position] err.\n");
        return -1;
    }
    position = item_json->valueint;

    item_json = cJSON_GetObjectItem(json, "DeviceID");
    if (item_json == NULL || item_json->valuestring == NULL) {
        err_printf("Json parse failed, get key[DeviceID] err.\n");
        return -1;
    }
    snprintf(device_id, sizeof(device_id), "%s", item_json->valuestring);

    item_json = cJSON_GetObjectItem(json, "DeviceType");
    if (item_json == NULL) {
        err_printf("Json parse failed, get key[DeviceType] err.\n");
        return -1;
    }
    snprintf(device_type, sizeof(device_type), "%s", item_json->valuestring);

    ret = LoadLocalCfgFile(&local_cfg);
    if (ret != 0) {
        err_printf("Load local config failed.\n");
        return -1;
    }
    local_cfg.position = position;
    snprintf(local_cfg.dev_id, sizeof(local_cfg.dev_id), "%s", device_id);
    snprintf(local_cfg.dev_type, sizeof(local_cfg.dev_type), "%s", device_type);
    if (strcmp(device_type, DEVICE_TYPE_RNA) == 0) {
        local_cfg.uart_cfg.baud_rate = 38400;
    } else if (strcmp(device_type, DEVICE_TYPE_PCR) == 0) {
        local_cfg.uart_cfg.baud_rate = 9600;
    }
    SetLocalCfg(&local_cfg);
    ret = SaveLocalCfgFile(&local_cfg);
    if (ret != 0) {
        err_printf("Save position to local config file failed.\n");
        return -1;
    }

    json_str = PackQueryDeviceReply(header->seq_id);
    if (json_str == NULL) {
        err_printf("Reply to cmd type:%s failed, reply json packe err.\n", header->type);
        return -1;
    }

    ret = WssSendData(json_str, strlen(json_str), WEBSOCKET_OP_TEXT);
    if (ret == 0) {
        warn_printf("Reply to cmd type:%s success.\n", header->type);
    } else {
        err_printf("Reply to cmd type:%s failed, wss send err.\n", header->type);
    }

    free(json_str);
    warn_printf("<!Notice!> Query device set finished, device will reboot after 3s!!!");
    sleep(3);
    warn_printf("<!Notice!> Reboot Now!!!\n");
    system_call("reboot now");
    return ret;
}

int HeartBeatHandler(WssHeader* header, cJSON* json) {
    int ret = 0;
    char* json_str = NULL;
    char time_str[DATATIME_LEN] = {0};
    char cmd[200] = {0};
    static unsigned short time_cnt = 0;

    if (header == NULL) {
        err_printf("Input err, WssHeader ptr is NULL.\n");
        return -1;
    }

    time_cnt++;
    cJSON* item_json = cJSON_GetObjectItem(json, "Time");
    if (item_json && item_json->valuestring) {
        snprintf(time_str, sizeof(time_str), "%s", item_json->valuestring);
        /*if (GetActionQueueSize() == 0 && GetCmdQueueSize() == 0) {
            if (time_cnt >= ResetSystermTimeCnt) {
                time_cnt = 0;
                snprintf(cmd, sizeof(cmd), "date -s \"%s\"", time_str);
                ret = system_call(cmd);
                warn_printf("Set local time, excute cmd : %s, ret = %d\r\n", cmd, ret);
            }    
        }*/
        if (s_time_syn_flag == 0) {
            snprintf(cmd, sizeof(cmd), "date -s \"%s\"", time_str);
            ret = system_call(cmd);
            warn_printf("Set local time, excute cmd : %s, ret = %d\r\n", cmd, ret);
            s_time_syn_flag = 1;
        } 
    }

    json_str = PackHeartBeatReply(header->seq_id);
    if (json_str == NULL) {
        err_printf("Reply to cmd type:%s failed, reply json packe err.\n", header->type);
        return -1;
    }
    ret = WssSendData(json_str, strlen(json_str), WEBSOCKET_OP_TEXT);
    if (ret != 0) {
        err_printf("Reply to cmd type:%s failed, wss send err.\n", header->type);
    }

    free(json_str);
    return ret;
}

int WorkTemplateHandler(cJSON* array_json, u_int32_t current_pharse_step) {
    cJSON* item_json = NULL;
    int array_size = 0;
    int i = 0;
    int ret = 0;
    bool loop_start_flag = 0;
    int loop_start_idx = 0;
    int loop_cnt = 0;
    int loop_end_idx = 0;
    int cmd_id = 0;
    int action_idx = 0;
    
    if (array_json == NULL) {
        err_printf("Input err, array json is NULL.\n");
        return -1;
    }

    array_size = cJSON_GetArraySize(array_json);

    for (i = 0; i < array_size; i++) {
        item_json = cJSON_GetArrayItem(array_json, i);
        if (item_json == NULL) {
            err_printf("Json parse failed, get %dth array item err.\n", i);
            return -1;
        }

        ActionHex action = {0};
        ret = ParseActionHex(item_json, &action);
        if (ret != 0) {
            err_printf("Array %dth item json parse err.\n", i);
            return -1;
        }

        if (strcmp(action.name, ACTION_LOOPSTART_FLAG) == 0) {
            loop_cnt = action.loop;
            if (loop_cnt < 1) {
                err_printf("Invalid loop_cnt:%d, drop loop start action.\n", loop_cnt);
            } else {
                loop_start_flag = true;
                loop_start_idx = i;
            }            
            continue;   
        }
        
        if ((strcmp(action.name, ACTION_LOOPEND_FLAG) == 0) && loop_start_flag) {
            loop_end_idx = i;
            while (loop_cnt-- > 0) {
                int loop_idx = loop_start_idx + 1;
                for (; loop_idx < loop_end_idx; loop_idx++) {
                    ActionHex loop_action = {0};

                    item_json = cJSON_GetArrayItem(array_json, loop_idx);
                    if (item_json == NULL) {
                        err_printf("Json parse failed, get %dth array item err.\n", i);
                        return -1;
                    }

                    ret = ParseActionHex(item_json, &loop_action);
                    if (ret != 0) {
                        err_printf("Array %dth item json parse err.\n", i);
                        return -1;
                    }

                    snprintf(loop_action.no, sizeof(loop_action.no), "%s:%d b%d", loop_action.name, loop_idx+1, loop_cnt+1);
                    action_idx = ActionEnQueue(&loop_action);
                    if ((strcmp(loop_action.name, SLAVE_CMD_TYPE_HEAT) == 0) && 
                        ((GetLastHeatStepIdx() < action_idx) && (action_idx < current_pharse_step))) {
                        SetLastHeatStepIdx(action_idx);
                    }
                }
            }
            
            loop_start_idx = 0;
            loop_end_idx = 0;
            loop_start_flag = false;
            loop_cnt = 0;
            continue;
        } else if ((strcmp(action.name, ACTION_LOOPEND_FLAG) == 0) && !loop_start_flag) {
            err_printf("Invalid loop end action, loop start action has not been found, drop action.\n");
            loop_start_idx = 0;
            loop_end_idx = 0;
            loop_start_flag = false;
            loop_cnt = 0;
            continue;
        } else if (loop_start_flag) {
            continue;
        }

        snprintf(action.no, sizeof(action.no), "%s:%d b%d", action.name, i+1, 1);
        action_idx = ActionEnQueue(&action);
        if ((strcmp(action.name, SLAVE_CMD_TYPE_HEAT) == 0) && 
            ((GetLastHeatStepIdx() < action_idx) && (action_idx < current_pharse_step))) {
            SetLastHeatStepIdx(action_idx);
        }
    }

    return 0;
}

int RNAAckReply(u_int32_t seq_id, RNAAck* ack) {
    char* json_str = NULL;
    int ret = 0;

    if (ack == NULL) {
        err_printf("Input err, ack ptr is NULL.\n");
        return -1;
    }

    json_str = PackRNAAckReport(seq_id, ack);
    if (json_str == NULL) {
        err_printf("Reply RNA ack failed, reply json packe err.\n");
        return -1;
    }
    ret = WssSendData(json_str, strlen(json_str), WEBSOCKET_OP_TEXT);
    if (ret != 0) {
        err_printf("Reply RNA ack failed, wss send err.\n");
    }

    free(json_str);
    return ret;
}

int RNAStopAckReply(u_int32_t seq_id, RNAAck* ack) {
    char* json_str = NULL;
    int ret = 0;

    if (ack == NULL) {
        err_printf("Input err, ack ptr is NULL.\n");
        return -1;
    }

    json_str = PackRNAAckReport(seq_id, ack);
    if (json_str == NULL) {
        err_printf("Reply RNA ack failed, reply json packe err.\n");
        return -1;
    }
    ret = WssSendData(json_str, strlen(json_str), WEBSOCKET_OP_TEXT);
    if (ret != 0) {
        err_printf("Reply RNA ack failed, wss send err.\n");
    }

    free(json_str);
    return ret;
}

int ExecFirstHeatCmd(u_int32_t seq_id, u_int8_t current_phase, u_int32_t last_heat_step_idx) {
    ActionHex action = {0};
    SlaveCtrlCmd cmd = {0};
    //RNADoneStatus status = {0};
    char sub_template_name[MAX_FILE_NAME_LEN] = {0};
    char* cmd_data = NULL;
    int cmd_data_len = 0;
    int ret = 0;
    int j = 0;

    GetTemplateName(s_done_status.template_name);
    ret = GetActionQueueItem(&action, last_heat_step_idx);
    if (ret != 0) {
        err_printf("Get last heat action err.\n");
        snprintf(s_done_status.status, sizeof(s_done_status.status), "error");
        snprintf(s_done_status.alarm, sizeof(s_done_status.alarm), "Get last heat action hex err");
        RNADoneStatusReport(seq_id, &s_done_status);
        return -1;
    }

    time_t now = time(0);
    struct tm* ptime = localtime(&now);
    char time_str[DATATIME_LEN] = {0};
    snprintf(time_str, sizeof(time_str), "%04d_%02d_%02d_%02d_%02d_%02d", 
		(1900 + ptime->tm_year), (ptime->tm_mon + 1), ptime->tm_mday, ptime->tm_hour, ptime->tm_min, ptime->tm_sec);

    cmd.retry_cnt = RETRY_NUM;
    cmd.cmd_id = 1;        
    cmd.action_hex_num = action.action_hex_num;
    for (j = 0; j < cmd.action_hex_num; j++) {
        snprintf(cmd.action_hex[j], SLAVE_CMD_HEX_LEN, "%s", action.action_hex[j]);
    }
    snprintf(cmd.cmd_type, sizeof(cmd.cmd_type), "%s", action.name);
    GetSubTemplateName(sub_template_name);
    snprintf(cmd.cmd_no, sizeof(cmd.cmd_no), "%s|%02d|%04d", sub_template_name, current_phase, last_heat_step_idx);
    snprintf(cmd.cmd_no_realtime, SLAVE_CMD_DESC_LEN, "%s|%s", cmd.cmd_no, time_str);

    cmd_data = PackSlaveCtrlCmd(&cmd, &cmd_data_len);
    if (cmd_data == NULL) {
        err_printf("Json pack slave ctrl cmd err, cmd:%s, no:%s.\n", cmd.cmd_type, cmd.cmd_no);
        snprintf(s_done_status.status, sizeof(s_done_status.status), "error");
        snprintf(s_done_status.alarm, sizeof(s_done_status.alarm), "Json pack slave ctrl cmd err, cmd:%s, no:%s.\n", cmd.cmd_type, cmd.cmd_no);
        RNADoneStatusReport(seq_id, &s_done_status);
        return -1;
    }

RETRY:
    while (cmd.retry_cnt)
    {
        if (s_task_exist) {
            cmd.retry_cnt = 0;
            break;
        }
        
        ret = UartSendSync(cmd_data, cmd_data_len);
        if (ret != 0) {
            snprintf(s_done_status.alarm, sizeof(s_done_status.alarm), "Json pack slave ctrl cmd err, cmd:%s, no:%s.\n", cmd.cmd_type, cmd.cmd_no);
            cmd.retry_cnt--;
            usleep(250000);
            err_printf("Json pack slave ctrl cmd err, cmd:%s, no:%s, remain retry cnt:%d.\n", cmd.cmd_type, cmd.cmd_no, cmd.retry_cnt);
        } else {
            warn_printf("Send cmd:%s, no:%s cmd_id:%u ok.\n", cmd.cmd_type, cmd.cmd_no, cmd.cmd_id);
            if (WaitAsyncCond(s_cond, SLAVE_CMD_HEAT_TIMEOUT) < 0) {
                snprintf(s_done_status.alarm, sizeof(s_done_status.alarm), "Slave ctrl cmd timeout, cmd:%s, no:%s.\n", cmd.cmd_type, cmd.cmd_no);
                cmd.retry_cnt--;
                err_printf("Slave ctrl cmd timeout, cmd:%s, no:%s, remain retry cnt:%d.\n", cmd.cmd_type, cmd.cmd_no, cmd.retry_cnt);
            } else {
                if (s_task_exist) {
                    cmd.retry_cnt = 0;
                }
                break;
            }
        }
    }

    if (s_slave_cmd_status) {
        if (cmd_data) {
            free(cmd_data);
            cmd_data = NULL;
        }       
    } else {
        snprintf(s_done_status.alarm, sizeof(s_done_status.alarm), "Slave ctrl cmd exec err, cmd:%s, no:%s.\n", cmd.cmd_type, cmd.cmd_no);
        if (cmd.retry_cnt > 0) {
            cmd.retry_cnt--;
        }       
        err_printf("Slave ctrl cmd exec err, cmd:%s, no:%s, remain retry cnt:%d.\n", cmd.cmd_type, cmd.cmd_no, cmd.retry_cnt);
        if (cmd.retry_cnt > 0) {
            goto RETRY;
        }
    }
    
    if (cmd.retry_cnt == 0) {
        if (cmd_data) {
            free(cmd_data);
            cmd_data = NULL;
        }
        snprintf(s_done_status.status, sizeof(s_done_status.status), "error");    
        RNADoneStatusReport(seq_id, &s_done_status);
        return -1;
    }

    return 0;
}

void* RNATaskWorkflowMgr(void* arg) {
    RNATaskInfo task_info = {0};
    //RNADoneStatus status = {0};
    int ret = 0;
    u_int32_t last_heat_step_idx = 0;
    char* cmd_data = NULL;
    int cmd_data_len = 0;
    u_int16_t timeout = 0;

    warn_printf("=======RNATaskWorkflowMgr entry============.\n");
    if (arg == NULL) {
        err_printf("Pthread arg is NULL, RNATaskWorkflowMgr pthread exit.\n");
        pthread_exit((void *)0);
    }
    memcpy(&task_info, arg, sizeof(RNATaskInfo));

    memset(&s_done_status, 0, sizeof(RNADoneStatus));
    snprintf(s_done_status.template_name, sizeof(s_done_status.template_name), "%s", task_info.template_name);
    s_cond = CreateAsyncCond(task_info.template_name);
    if (s_cond == NULL) {
        err_printf("Create async cond err.\n");
        snprintf(s_done_status.status, sizeof(s_done_status.status), "error");
        snprintf(s_done_status.alarm, sizeof(s_done_status.alarm), "Create async cond err");
        RNADoneStatusReport(task_info.seq_id, &s_done_status);
        snprintf(g_status.linux_status, sizeof(g_status.linux_status), "error");
        snprintf(g_status.linux_alarm, sizeof(g_status.linux_alarm), "Create async cond err");
        DeinitWorkflowMgr();
        warn_printf("======RNATaskWorkflowMgr exit==========.\n");
        pthread_exit((void *)0);
    }

    last_heat_step_idx = GetLastHeatStepIdx();
    if ((0 < last_heat_step_idx) && (last_heat_step_idx < task_info.current_phase_step)) {
        ret = ExecFirstHeatCmd(task_info.seq_id, task_info.current_phase, last_heat_step_idx);
        if (ret != 0) {
            err_printf("Exec first heat cmd failed, RNA task workflow pthread exit.\n");
            DestroyAsyncCond(s_cond);
            s_cond = NULL;
            DeinitWorkflowMgr();
            warn_printf("======RNATaskWorkflowMgr exit==========.\n");
            pthread_exit((void *)0);
        }    
    }

    while (!s_task_exist) {
        if (GetCmdQueueSize() == 0) {
            warn_printf("All cmd is done, template:%s batch_id:%s task is finished.\n", task_info.template_name, task_info.batch_id);
            break;
        }

        SlaveCtrlCmd cmd = {0};
        SetRealTimeCmdNo();
        GetCmdQueueFront(&cmd);
        if ((0 < last_heat_step_idx) && (last_heat_step_idx < task_info.current_phase_step)) {
            cmd.cmd_id += 1;
        }
        if (strcmp(cmd.cmd_type, SLAVE_CMD_TYPE_HEAT) == 0) {
            timeout = SLAVE_CMD_HEAT_TIMEOUT;
        } else {
            timeout = SLAVE_CMD_RNA_TIMEOUT;
        }

        cmd_data = PackSlaveCtrlCmd(&cmd, &cmd_data_len);
        if (cmd_data == NULL) {
            err_printf("Json pack slave ctrl cmd err, cmd:%s, no:%s.\n", cmd.cmd_type, cmd.cmd_no);
            snprintf(s_done_status.status, sizeof(s_done_status.status), "error");
            snprintf(s_done_status.alarm, sizeof(s_done_status.alarm), "Json pack slave ctrl cmd err, cmd:%s, no:%s.\n", cmd.cmd_type, cmd.cmd_no);
            RNADoneStatusReport(task_info.seq_id, &s_done_status);
            snprintf(g_status.linux_status, sizeof(g_status.linux_status), "error");
            snprintf(g_status.linux_alarm, sizeof(g_status.linux_alarm), "Json pack slave ctrl cmd err, cmd:%s, no:%s.\n", cmd.cmd_type, cmd.cmd_no);
            DestroyAsyncCond(s_cond);
            s_cond = NULL;
            DeinitWorkflowMgr();
            warn_printf("======RNATaskWorkflowMgr exit==========.\n");
            pthread_exit((void *)0);
        }

RETRY:
        while (cmd.retry_cnt)
        {
            if (s_task_exist) {
                cmd.retry_cnt = 0;
                break;
            }
            
            ret = UartSendSync(cmd_data, cmd_data_len);
            if (ret != 0) {
                snprintf(s_done_status.alarm, sizeof(s_done_status.alarm), "Uart send slave ctrl cmd err, cmd:%s, no:%s.\n", cmd.cmd_type, cmd.cmd_no);
                snprintf(g_status.linux_alarm, sizeof(g_status.linux_alarm), "Uart send slave ctrl cmd err, cmd:%s, no:%s.\n", cmd.cmd_type, cmd.cmd_no);
                cmd.retry_cnt--;
                usleep(200000);
                err_printf("Uart send slave ctrl cmd err, cmd:%s, no:%s, remain retry cnt:%d.\n", cmd.cmd_type, cmd.cmd_no, cmd.retry_cnt);
            } else {
                warn_printf("Send cmd:%s, no:%s cmd_id:%u ok.\n", cmd.cmd_type, cmd.cmd_no, cmd.cmd_id);
                if (WaitAsyncCond(s_cond, timeout) < 0) {
                    snprintf(s_done_status.alarm, sizeof(s_done_status.alarm), "Slave ctrl cmd timeout, cmd:%s, no:%s.\n", cmd.cmd_type, cmd.cmd_no);
                    snprintf(g_status.linux_alarm, sizeof(g_status.linux_alarm), "Slave ctrl cmd timeout, cmd:%s, no:%s.\n", cmd.cmd_type, cmd.cmd_no);
                    cmd.retry_cnt--;
                    err_printf("Slave ctrl cmd timeout, cmd:%s, no:%s, remain retry cnt:%d.\n", cmd.cmd_type, cmd.cmd_no, cmd.retry_cnt);
                } else {
                    if (s_task_exist) {
                        cmd.retry_cnt = 0;
                    }
                    break;
                }
            }
        }

        if (cmd.retry_cnt == 0) {
            s_task_exist = true;
        } else {
            if (s_slave_cmd_status) {
                CmdDeQueue();
                warn_printf("Slave cmd:%s, cmd_id:%u exec success, cmd size:%d.\n", cmd.cmd_type, cmd.cmd_id, GetCmdQueueSize());
            } else {                
                snprintf(s_done_status.alarm, sizeof(s_done_status.alarm), "Slave ctrl cmd exec err, cmd:%s, no:%s.\n", cmd.cmd_type, cmd.cmd_no);
                snprintf(g_status.linux_alarm, sizeof(g_status.linux_alarm), "Slave ctrl cmd exec err, cmd:%s, no:%s.\n", cmd.cmd_type, cmd.cmd_no);
                cmd.retry_cnt--;
                err_printf("Slave ctrl cmd exec err, cmd:%s, no:%s, remain retry cnt:%d.\n", cmd.cmd_type, cmd.cmd_no, cmd.retry_cnt);
                if (cmd.retry_cnt > 0) {
                    goto RETRY;
                } else {
                    s_task_exist = true;
                }
            }  
        }
        free(cmd_data);
    }

    if (s_task_exist) {
        snprintf(s_done_status.status, sizeof(s_done_status.status), "error");
        RNADoneStatusReport(task_info.seq_id, &s_done_status);
        snprintf(g_status.linux_status, sizeof(g_status.linux_status), "error");
    } else {
        snprintf(s_done_status.status, sizeof(s_done_status.status), "ok");
        RNADoneStatusReport(task_info.seq_id, &s_done_status);
        snprintf(g_status.linux_status, sizeof(g_status.linux_status), "free");
    }

    DeinitWorkflowMgr();
    DestroyAsyncCond(s_cond);
    s_cond = NULL;
    warn_printf("======RNATaskWorkflowMgr exit==========.\n");
    pthread_exit((void *)0);
}

int RNAReqHandler(WssHeader* header, cJSON* root_json) {
    int ret = 0;
    cJSON* item_json = NULL;
    static RNATaskInfo task_info = {0};
    RNAAck ack = {0};
    int force = 0;

    if (header == NULL || root_json == NULL) {
        err_printf("Input err, WssHeader or json ptr is NULL.\n");
        return -1;
    }

    item_json = cJSON_GetObjectItem(root_json, "Force");
    if (item_json != NULL) {
        force = item_json->valueint;
    } else {
        force = 0;
    }
    if (GetActionQueueSize() && GetCmdQueueSize()) {
        if (force == 1) {
            s_task_exist = true;
            if (s_cond) {
                SignalAsyncCond(s_cond, NULL, NULL);
            }
            sleep(3);

            RNADoneStatus status = {0};
            snprintf(status.template_name, sizeof(status.template_name), "%s", task_info.template_name);
            snprintf(status.status, sizeof(status.status), "error");
            snprintf(status.alarm, sizeof(status.alarm), "RNA workflow force to exit");
            RNADoneStatusReport(task_info.seq_id, &status);
            usleep(10000);
            pthread_mutex_lock(&s_lock);
            if (s_report_rna_finish_status_timer_info) {               
                s_report_rna_finish_status_timer_info->quit_flag = 1;
                s_report_rna_finish_status_timer_info = NULL;
                if (s_report_rna_finish_status_thread_id != 0) {
                    s_report_rna_finish_status_thread_id = 0;
                }
                s_rna_finish_status_ack = 1;
            }
            pthread_mutex_unlock(&s_lock);
                    
            warn_printf("Template:%s is force to stop.\n", task_info.template_name);
        } else {
            snprintf(ack.alarm, sizeof(ack.alarm), "RNA template:%s is running, cannot create new workflow.\n", task_info.template_name);
            err_printf("RNA template:%s is running, cannot create new workflow.\n", task_info.template_name);
            goto FAIL;
        }
    }

    memset(&task_info, 0, sizeof(RNATaskInfo));
    task_info.seq_id = header->seq_id;
    s_task_exist = false;

    item_json = cJSON_GetObjectItem(root_json, "Template");
    if (item_json == NULL || item_json->valuestring == NULL) {
        err_printf("Json parse key[Template] err.\n");
        snprintf(ack.alarm, sizeof(ack.alarm), "Json parse error");
        goto FAIL;
    }
    snprintf(task_info.template_name, sizeof(task_info.template_name), "%s", item_json->valuestring);

    item_json = cJSON_GetObjectItem(root_json, "CurrentPhase");
    if (item_json == NULL) {
        err_printf("Json parse key[CurrentPhase] err.\n");
        snprintf(ack.alarm, sizeof(ack.alarm), "Json parse error");
        goto FAIL;
    }
    task_info.current_phase = item_json->valueint;

    item_json = cJSON_GetObjectItem(root_json, "CurrentPhaseStep");
    if (item_json == NULL) {
        err_printf("Json parse key[CurrentPhaseStep].\n");
        snprintf(ack.alarm, sizeof(ack.alarm), "Json parse error");
        goto FAIL;
    }
    task_info.current_phase_step = item_json->valueint;

    item_json = cJSON_GetObjectItem(root_json, "BatchID");
    if (item_json == NULL || item_json->valuestring == NULL) {
        snprintf(ack.alarm, sizeof(ack.alarm), "Json parse error");
        err_printf("Json parse key[BatchID].\n");
        goto FAIL;
    }
    snprintf(task_info.batch_id, sizeof(task_info.batch_id), "%s", item_json->valuestring);

    item_json = cJSON_GetObjectItem(root_json, "TotalTime");
    if (item_json == NULL) {
        snprintf(ack.alarm, sizeof(ack.alarm), "Json parse error");
        err_printf("Json parse key[TotalTime].\n");
        goto FAIL;
    }
    task_info.total_time = item_json->valueint;
    
    ret = InitWorkflowMgr(task_info.seq_id, task_info.template_name, task_info.current_phase, task_info.current_phase_step);
    if (ret != 0) {
        snprintf(ack.alarm, sizeof(ack.alarm), "Workflow init err");
        err_printf("Init workflow mgr failed.\n");
        goto FAIL;
    }
    SetTaskTotalTime(task_info.total_time);
    
    item_json = cJSON_GetObjectItem(root_json, "WorkTemplate");
    if (item_json == NULL) {
        snprintf(ack.alarm, sizeof(ack.alarm), "Json parse error");
        err_printf("Json parse key[WorkTemplate] err.\n");
        goto FAIL;
    }

    ret = WorkTemplateHandler(item_json, task_info.current_phase_step);
    if (ret != 0) {
        snprintf(ack.alarm, sizeof(ack.alarm), "Json parse error");
        err_printf("Work template json parse err.\n");
        DeinitWorkflowMgr();
        goto FAIL;
    }

    InitCmdQueue();
    warn_printf("Cmd queue size:%d.\n", GetCmdQueueSize());
    ret = pthread_create(&task_info.workflow_thread_id, NULL, RNATaskWorkflowMgr, &task_info);
    if (ret != 0) {
        snprintf(ack.alarm, sizeof(ack.alarm), "Create RNA workflow pthread err");
        err_printf("Create RNA task workflow pthread err.\n");
        DeinitWorkflowMgr();
        goto FAIL;
    } else {
        snprintf(g_status.linux_status, sizeof(g_status.linux_status), "running");
        pthread_detach(task_info.workflow_thread_id);
    }

    snprintf(ack.status, sizeof(ack.status), "ok");
    RNAAckReply(header->seq_id, &ack);
    return 0;
    
FAIL:
    snprintf(ack.status, sizeof(ack.status), "error");
    RNAAckReply(header->seq_id, &ack);
    return -1;
}

int RNAStopHandler(WssHeader* header) {
    RNAAck ack = {0};

    if (header == NULL) {
        err_printf("Input err, WssHeader is NULL.\n");
        return -1;
    }

    if (GetActionQueueSize() && GetCmdQueueSize()) {
        s_task_exist = true;
        if (s_cond) {
            SignalAsyncCond(s_cond, NULL, NULL);
        }
        sleep(3);
    }

    snprintf(ack.status, sizeof(ack.status), "ok");
    RNAStopAckReply(header->seq_id, &ack);
    return 0;
}

int UpgradeDoneStatusReport(u_int32_t seq_id, UpgradeDoneStatus* status) {
    char* json_str = NULL;
    int ret = 0;

    if (status == NULL) {
        err_printf("Input err, status ptr is NULL.\n");
        return -1;
    }

    json_str = PackUpgradeDoneReport(seq_id, status);
    if (json_str == NULL) {
        err_printf("Report upgrade done status failed, json packe err.\n");
        return -1;
    }
    ret = WssSendData(json_str, strlen(json_str), WEBSOCKET_OP_TEXT);
    if (ret != 0) {
        err_printf("Report upgrade done status failed, wss send err.\n");
    }

    free(json_str);
    return ret;
}

int UpgradeAckReply(u_int32_t seq_id, RNAAck* ack) {
    char* json_str = NULL;
    int ret = 0;

    if (ack == NULL) {
        err_printf("Input err, ack ptr is NULL.\n");
        return -1;
    }

    json_str = PackUpgradeAckReport(seq_id, ack);
    if (json_str == NULL) {
        err_printf("Reply upgrade ack failed, reply json pack err.\n");
        return -1;
    }
    ret = WssSendData(json_str, strlen(json_str), WEBSOCKET_OP_TEXT);
    if (ret != 0) {
        err_printf("Reply upgrade ack failed, wss send err.\n");
    }

    free(json_str);
    return ret;
}

int UpgradeHandler(WssHeader* header, cJSON* root_json, char* data) {
    RNAAck ack = {0};
    UpgradeDescInfo desc_info = {0};
    UpgradeDoneStatus status = {0};
    MsgInfo msg = {0};
    int ret = 0;

    if (header == NULL || root_json == NULL || data == NULL) {
        err_printf("Input err, WssHeader or json or data ptr is NULL.\n");
        return -1;
    }

    snprintf(ack.status, sizeof(ack.status), "ok");

    ret = ParseUpgradeDescInfo(root_json, &desc_info);
    if (ret != 0) {
        err_printf("Upgrade desc info json parse err.\n");
        snprintf(ack.status, sizeof(ack.status), "error");
        snprintf(ack.alarm, sizeof(ack.alarm), "Upgrade desc info json parse error");
        UpgradeAckReply(header->seq_id, &ack);
        return -1;
    }

    ret = ParseUpgradeVersionFile(data+sizeof(WssBinaryHeader)+header->desc_data_len, &desc_info);
    if (ret == -1) {
        err_printf("Upgrade version file parse err.\n");
        snprintf(ack.status, sizeof(ack.status), "error");
        snprintf(ack.alarm, sizeof(ack.alarm), "Upgrade version file parse error");
        UpgradeAckReply(header->seq_id, &ack);
        return -1;
    } else if (ret == -2) {
        err_printf("Upgrade version file md5 check err.\n");
        snprintf(ack.status, sizeof(ack.status), "error");
        snprintf(ack.alarm, sizeof(ack.alarm), "Upgrade version file md5 check error");
        UpgradeAckReply(header->seq_id, &ack);
        return -1;
    }

    UpgradeAckReply(header->seq_id, &ack);

    if (GetActionQueueSize() && GetCmdQueueSize()) {
        err_printf("RNA template is running, cannot start upgrade, please stop RNA before upgrade.\n");
        snprintf(status.status, sizeof(status.status), "error");
        snprintf(status.alarm, sizeof(status.alarm), "RNA task is running");
        UpgradeDoneStatusReport(header->seq_id, &status);
        return -1;
    }

    msg.header.src_app = APP_RNAMGR_ID;
    msg.header.dst_app = APP_UPGRADE_ID;
    msg.header.handle_id = header->seq_id;
    msg.header.data_len = sizeof(UpgradeDescInfo);
    memcpy(msg.data, &desc_info, sizeof(UpgradeDescInfo));
    ret = SendMsg(APP_UPGRADE_ID, MSG_ID_APP_UPGRADE, &msg);
    if (ret != 0) {
        err_printf("Send upgrade msg to UpgradeApp failed.\n");
        snprintf(status.status, sizeof(status.status), "error");
        snprintf(status.alarm, sizeof(status.alarm), "Send upgrade msg to UpgradeApp failed");
        UpgradeDoneStatusReport(header->seq_id, &status);
        return -1;
    }

    return 0;
}

int RNADoneStatusReplyHandler(void* arg) {
    s_rna_finish_status_ack = 1;
    pthread_mutex_lock(&s_lock);
    if (s_report_rna_finish_status_timer_info) {       
        s_report_rna_finish_status_timer_info->quit_flag = 1;
        if (s_report_rna_finish_status_thread_id != 0) {
            s_report_rna_finish_status_thread_id = 0;
        }
        s_report_rna_finish_status_timer_info = NULL;       
    }
    pthread_mutex_unlock(&s_lock);
    memset(&s_done_status, 0, sizeof(RNADoneStatus));

    return 0;
}

int SetLogLevelHandler(WssHeader* header, cJSON* json) {
    int ret = 0;
    char* json_str = NULL;
    u_int8_t log_level = 2;
    char cmd[200] = {0};
    u_int8_t status = 0;

    if (header == NULL) {
        err_printf("Input err, WssHeader ptr is NULL.\n");
        return -1;
    }

    cJSON* item_json = cJSON_GetObjectItem(json, "LogLevel");
    if (item_json) {
        log_level = item_json->valueint;
        if (log_level < LOGGER_ERR || log_level > LOGGER_INFO_D) {
            err_printf("Set log level failed, log_level:%d is invalid, 0 < log_level < 6.\n", log_level);
            status = 1;
        } else {
            SetLoggerLevel(log_level);
            warn_printf("RnaMgrApp set log_level:%d successfully.\n", log_level);
        }
    } else {
        err_printf("Json parse key[LogLevel] err.\n");
        status = 2;
    }

    json_str = PackSetLogLevelReply(header->seq_id, status);
    if (json_str == NULL) {
        err_printf("Reply to cmd type:%s failed, reply json pack err.\n", header->type);
        return -1;
    }
    ret = WssSendData(json_str, strlen(json_str), WEBSOCKET_OP_TEXT);
    if (ret != 0) {
        err_printf("Reply to cmd type:%s failed, wss send err.\n", header->type);
    }

    free(json_str);
    return ret;
}

int UpdateConfigReply(u_int32_t seq_id, RNAAck* status) {
    int ret = 0;
    char* json_str = NULL;

    if (status == NULL) {
        err_printf("Input err, status ptr is NULL, update config reply failed.\n");
        return -1;
    }

    json_str = PackUpdateCfgReply(seq_id, status);
    if (json_str == NULL) {
        err_printf("Reply to cmd type:%s failed, reply json pack err.\n", CMD_TYPE_UPDATE_CONFIG);
        return -1;
    }
    ret = WssSendData(json_str, strlen(json_str), WEBSOCKET_OP_TEXT);
    if (ret != 0) {
        err_printf("Reply to cmd type:%s failed, wss send err.\n", CMD_TYPE_UPDATE_CONFIG);
    }

    free(json_str);
    return ret;
}

int UpdateConfigHandler(WssHeader* header, cJSON* json) {
    int ret = 0;
    char* json_str = NULL;
    u_int8_t log_level = 2;
    char cmd[200] = {0};
    RNAAck status = {0};

    if (header == NULL) {
        err_printf("Input err, WssHeader ptr is NULL.\n");
        return -1;
    }

     if (GetActionQueueSize() > 0) {
        err_printf("Rna task is running, cannot update config.\n");
        snprintf(status.status, sizeof(status.status), "error");
        snprintf(status.alarm, sizeof(status.alarm), "Rna task is running, cannot update config.\n");
        UpdateConfigReply(header->seq_id, &status);
        return -1;
    }

    cJSON* child_json = cJSON_GetObjectItem(json, "Config");
    if (child_json) {
        cJSON* item_json = NULL;
        cJSON* child_item_json = NULL;
        cJSON* uart_cfg_json = cJSON_GetObjectItem(child_json, "Uart");
        if (uart_cfg_json) {
            LocalCfg local_cfg = {0};
            LoadLocalCfgFile(&local_cfg);
            item_json = cJSON_GetObjectItem(uart_cfg_json, "BaudRate");
            if (item_json) {
                local_cfg.uart_cfg.baud_rate = item_json->valueint;
            }

            item_json = cJSON_GetObjectItem(uart_cfg_json, "DataBits");
            if (item_json) {
                local_cfg.uart_cfg.data_bits = item_json->valueint;
            }

            item_json = cJSON_GetObjectItem(uart_cfg_json, "StopBits");
            if (item_json) {
                local_cfg.uart_cfg.stop_bits = item_json->valueint;
            }

            item_json = cJSON_GetObjectItem(uart_cfg_json, "Parity");
            if (item_json && item_json->valuestring) {
                snprintf(local_cfg.uart_cfg.parity, sizeof(local_cfg.uart_cfg.parity), "%s", item_json->valuestring);
            }

            DeinitUartComm();
            sleep(3);
            ret = InitUartComm(&local_cfg.uart_cfg, 1);
            if (ret < 0) {
                err_printf("Uart communication use new cfg init err.\n");
                snprintf(status.status, sizeof(status.status), "error");
                snprintf(status.alarm, sizeof(status.alarm), "Uart cfg update failed, uart restart failed.\n");
                UpdateConfigReply(header->seq_id, &status);
                return -1;
            } else {
                UartPacketHandlerReg(UartPacketHandler);
                SaveLocalCfgFile(&local_cfg);
            }    
        }

        cJSON* file_mgr_cfg_json = cJSON_GetObjectItem(child_json, "FileMgr");
        if (file_mgr_cfg_json) {
            FileManager file_mgf_cfg = {0};
            ReadFileMgrCfg(&file_mgf_cfg);
            item_json = cJSON_GetObjectItem(file_mgr_cfg_json, "RnaLog");
            if (item_json) {
                child_item_json = cJSON_GetObjectItem(item_json, "CleanTime");
                if (child_item_json) {
                    file_mgf_cfg.mgr_cfg[MGR_FILE_TYPE_RNA_APP_LOG].clean_time = child_item_json->valueint;
                }

                child_item_json = cJSON_GetObjectItem(item_json, "CleanThreshold");
                if (child_item_json) {
                    file_mgf_cfg.mgr_cfg[MGR_FILE_TYPE_RNA_APP_LOG].clean_threshold = child_item_json->valueint;
                }
            }

            item_json = cJSON_GetObjectItem(file_mgr_cfg_json, "PcrLog");
            if (item_json) {
                child_item_json = cJSON_GetObjectItem(item_json, "CleanTime");
                if (child_item_json) {
                    file_mgf_cfg.mgr_cfg[MGR_FILE_TYPE_PCR_APP_LOG].clean_time = child_item_json->valueint;
                }

                child_item_json = cJSON_GetObjectItem(item_json, "CleanThreshold");
                if (child_item_json) {
                    file_mgf_cfg.mgr_cfg[MGR_FILE_TYPE_PCR_APP_LOG].clean_threshold = child_item_json->valueint;
                }
            }

            item_json = cJSON_GetObjectItem(file_mgr_cfg_json, "PcrResult");
            if (item_json) {
                child_item_json = cJSON_GetObjectItem(item_json, "CleanTime");
                if (child_item_json) {
                    file_mgf_cfg.mgr_cfg[MGR_FILE_TYPE_PCR_RESULT].clean_time = child_item_json->valueint;
                }

                child_item_json = cJSON_GetObjectItem(item_json, "CleanThreshold");
                if (child_item_json) {
                    file_mgf_cfg.mgr_cfg[MGR_FILE_TYPE_PCR_RESULT].clean_threshold = child_item_json->valueint;
                }
            }

            item_json = cJSON_GetObjectItem(file_mgr_cfg_json, "Disk");
            if (item_json) {
                child_item_json = cJSON_GetObjectItem(item_json, "UsedRateThreshold");
                if (child_item_json) {
                    file_mgf_cfg.disk_used_rate_threshold = child_item_json->valuedouble;
                }
            }

            SetFileMgrCfg(&file_mgf_cfg);
            SaveFileManagerFile(&file_mgf_cfg);
        }
    } else {
        err_printf("Json parse key[Config] err.\n");
        snprintf(status.status, sizeof(status.status), "error");
        snprintf(status.alarm, sizeof(status.alarm), "Json parse key[Config] err.\n");
        UpdateConfigReply(header->seq_id, &status);
    }

    snprintf(status.status, sizeof(status.status), "ok");
    UpdateConfigReply(header->seq_id, &status);

    return ret;
}

int FactoryResetReply(u_int32_t seq_id, RNAAck* status) {
    int ret = 0;
    char* json_str = NULL;

    if (status == NULL) {
        err_printf("Input err, status ptr is NULL, reset factory config reply failed.\n");
        return -1;
    }

    json_str = PackFactoryResetReply(seq_id, status);
    if (json_str == NULL) {
        err_printf("Reply to cmd type:%s failed, reply json pack err.\n", CMD_TYPE_FACTORY_RESET);
        return -1;
    }
    ret = WssSendData(json_str, strlen(json_str), WEBSOCKET_OP_TEXT);
    if (ret != 0) {
        err_printf("Reply to cmd type:%s failed, wss send err.\n", CMD_TYPE_FACTORY_RESET);
    }

    free(json_str);
    return ret;
}

int FactoryResetHandler(WssHeader* header, cJSON* json) {
    int ret = 0;
    int delay = 5;
    char cmd[512] = {0};
    RNAAck status = {0};

    if (header == NULL) {
        err_printf("Input err, WssHeader ptr is NULL.\n");
        return -1;
    }

    if (GetActionQueueSize() > 0) {
        err_printf("Rna task is running, cannot reset factory config.\n");
        snprintf(status.status, sizeof(status.status), "error");
        snprintf(status.alarm, sizeof(status.alarm), "Rna task is running, cannot reset factory config.\n");
        FactoryResetReply(header->seq_id, &status);
        return -1;
    }

    cJSON* item_json = cJSON_GetObjectItem(json, "Delay");
    if (item_json) {
        delay = item_json->valueint;
    } else {
        err_printf("Json parse key[Delay] err.\n");
    }

    snprintf(cmd, sizeof(cmd), "cp -f %s %slocal_config/local_cfg_bk.json; cp -f %s %slocal_config/file_mgr_cfg_bk.json; cp -f %s %sserver_config/srv_cfg_bk.json;", 
        LOCAL_CFG_FILE, CONFIG_DIR_PATH, FILE_MGR_CFG_FILE, CONFIG_DIR_PATH, SERVER_CFG_FILE, CONFIG_DIR_PATH);
    if (system_call(cmd) != 0) {
		err_printf("Back up current config files failed. Call sys_cmd:%s failed.\n", cmd);
        snprintf(status.status, sizeof(status.status), "error");
        snprintf(status.alarm, sizeof(status.alarm), "Back up current config files failed.\n");
        FactoryResetReply(header->seq_id, &status);
        return -1;
	} else {
		warn_printf("Back up current config files success. Call sys_cmd:%s success.\n", cmd);
	}

    memset(cmd, 0, sizeof(cmd));
    snprintf(cmd, sizeof(cmd), "cp -f %slocal_config/local_cfg.json %s; cp -f %slocal_config/file_mgr_cfg.json %s; cp -f %sserver_config/srv_cfg.json %s;", 
        ORI_CONFIG_DIR_PATH, LOCAL_CFG_FILE, ORI_CONFIG_DIR_PATH, FILE_MGR_CFG_FILE, ORI_CONFIG_DIR_PATH, SERVER_CFG_FILE);
    if (system_call(cmd) != 0) {
		err_printf("Reset ori factory config files failed. Call sys_cmd:%s failed.\n", cmd);
        memset(cmd, 0, sizeof(cmd));
        snprintf(cmd, sizeof(cmd), "cp -f %slocal_config/local_cfg_bk.json %s; cp -f %slocal_config/file_mgr_cfg_bk.json %s; cp -f %sserver_config/srv_cfg_bk.json %s;", 
            CONFIG_DIR_PATH, LOCAL_CFG_FILE, CONFIG_DIR_PATH, FILE_MGR_CFG_FILE, CONFIG_DIR_PATH, SERVER_CFG_FILE);
        if (system_call(cmd) != 0) {
            err_printf("Restore config files failed. Call sys_cmd:%s failed.\n", cmd);
        } else {
            warn_printf("Restore config files success. Call sys_cmd:%s success.\n", cmd);
        }

        snprintf(status.status, sizeof(status.status), "error");
        snprintf(status.alarm, sizeof(status.alarm), "Reset ori factory config files failed.\n");
        FactoryResetReply(header->seq_id, &status);
        return -1;
	} else {
		warn_printf("Reset ori factor config files success. Call sys_cmd:%s success.\n", cmd);
        snprintf(status.status, sizeof(status.status), "ok");
        FactoryResetReply(header->seq_id, &status);
	}

    warn_printf("<!Notice!> Factory reset is finished, device will reboot after %ds.\n", delay);
    sleep(delay);
    warn_printf("<!Notice!> Reboot Now!!!\n");
    system_call("reboot now");
    return ret;
}

int WssDataHandler (const char *data, size_t len, u_int8_t data_type) {
    int ret = 0;
    char* json_str = NULL;
    WssHeader header = {0};
    cJSON* root_json = NULL;
    RNAAck ack = {0};

    if (data == NULL || len == 0) {
        err_printf("Input err, data ptr is NULL or len is 0.\n");
        return -1;
    }

    if (data_type == WEBSOCKET_OP_TEXT) {
        warn_printf("Recv wss data:%s.\n", data);
        root_json = WssDataHeaderParse(&header, data);
    } else if (data_type == WEBSOCKET_OP_BINARY) {
        root_json = WssBinaryDataHeaderParse(&header, data);
    } else {
        err_printf("Undefined data_type:%d.\n", data_type);
        return -1;
    }

    if (root_json == NULL) {
        err_printf("Wss parse data header err.\n");
        snprintf(ack.status, sizeof(ack.status), "error");
        snprintf(ack.alarm, sizeof(ack.alarm), "Json parse error");
        if (strcmp(header.type, CMD_TYPE_RNA_REQ) == 0) {
            RNAAckReply(header.seq_id, &ack);
        } else if (strcmp(header.type, CMD_TYPE_RNA_STOP) == 0) {
            RNAStopAckReply(header.seq_id, &ack);
        } else if (strcmp(header.type, CMD_TYPE_UPGRADE) == 0) {
            UpgradeAckReply(header.seq_id, &ack);
        }
        return -1;
    }

    if (strcmp(header.type, CMD_TYPE_QUERY_DEVICE) == 0) {
        ret = QueryDeviceHandler(&header, root_json);
    } else if (strcmp(header.type, CMD_TYPE_HEART_BEAT) == 0) {
        ret = HeartBeatHandler(&header, root_json);
    } else if (strcmp(header.type, CMD_TYPE_RNA_REQ) == 0) {
        ret = RNAReqHandler(&header, root_json);
    } else if (strcmp(header.type, CMD_TYPE_RNA_STOP) == 0) {
        ret = RNAStopHandler(&header);
    } else if (strcmp(header.type, CMD_TYPE_UPGRADE) == 0) {
        ret = UpgradeHandler(&header, root_json, data);
    } else if (strcmp(header.type, CMD_TYPE_RNA_DONE_STATUS_REPLY) == 0) {
        ret = RNADoneStatusReplyHandler(root_json);
    } else if (strcmp(header.type, CMD_TYPE_SET_LOG_LEVER) == 0) {
        ret = SetLogLevelHandler(&header, root_json);
    } else if (strcmp(header.type, CMD_TYPE_UPDATE_CONFIG) == 0) {
        ret = UpdateConfigHandler(&header, root_json);
    } else if (strcmp(header.type, CMD_TYPE_FACTORY_RESET) == 0) {
        ret = FactoryResetHandler(&header, root_json);
    }
        
    cJSON_Delete(root_json);

    return ret;
}
