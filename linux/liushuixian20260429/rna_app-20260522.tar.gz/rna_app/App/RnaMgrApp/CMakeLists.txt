cmake_minimum_required(VERSION 3.1 FATAL_ERROR)
project(RnaMgrApp)

add_subdirectory("src")