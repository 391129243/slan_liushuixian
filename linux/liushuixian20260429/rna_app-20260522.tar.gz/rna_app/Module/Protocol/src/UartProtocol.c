#include "UartProtocol.h"
#include "Uart.h"
#include "Logger.h"
#include "cJSON.h"

u_int16_t GenCRCCheck(u_int8_t* data, u_int16_t data_len) {
    u_int16_t check_sum = 0;
    int i = 0;

    if (data == NULL || data_len == 0) {
        err_printf("Input err, data ptr is NULL or data_len is 0.\n");
        return 0;
    }

    for (i = 0; i < data_len; i++) {
        check_sum += data[i];
    }

    return check_sum;
}

u_int8_t* UartPacketWrapper(u_int8_t* data, u_int16_t data_len) {
    UartHeader header = {0};
    UartTailer tailer = {0};
    u_int16_t packet_len = 0;
    u_int16_t crc = 0;

    if (data == NULL || data_len == 0) {
        err_printf("Input err, data ptr is NULL or data_len is 0.\n");
        return 0;
    }

    header.header_flag_1 = HEADER_FLAG_1;
    header.header_flag_2 = HEADER_FLAG_2;
    header.data_len = htons(data_len);
    header.func_id = 0x01;

    crc = GenCRCCheck(data, data_len);
    tailer.crc = htons(crc);
    tailer.tailer_flag_1 = TAILER_FLAG_1;
    tailer.tailer_flag_2 = TAILER_FLAG_2;
    tailer.tailer_flag_3 = TAILER_FLAG_3;

    packet_len = sizeof(UartHeader) + data_len + sizeof(UartHeader);
    u_int8_t* packet = malloc(packet_len);
    if (packet == NULL) {
        err_printf("Malloc mem for packet err.\n");
        return NULL;
    }

    memcpy(packet, &header, sizeof(UartHeader));
    memcpy(packet + sizeof(UartHeader), data, data_len);
    memcpy(packet + sizeof(UartHeader) + data_len, &tailer, sizeof(UartHeader));

    return packet;
}

int UartPacketParse(UartHeader *header, u_int8_t* packet, u_int16_t packet_len) {
    u_int8_t min_len = sizeof(UartHeader) + 2;
    UartTailer tailer = {0};
    u_int16_t data_len = 0;
    u_int16_t crc = 0;
    u_int16_t gen_crc = 0;

    if (packet == NULL || packet_len == 0) {
        err_printf("Input err, packet ptr is NULL or packet len is 0.\n");
        return -1;
    }

    if (header == NULL) {
        err_printf("Input err, UartHeader ptr is NULL.\n");
        return -1;
    }

    if (packet_len < min_len) {
        err_printf("Packet len:%d is invalid, less than packet min len:%d.\n", packet_len, min_len);
        return -1;
    }

    memcpy(header, packet, sizeof(UartHeader));
    data_len = ntohs(header->data_len);
    memcpy(&tailer, packet+sizeof(UartHeader)+data_len, sizeof(UartTailer));
    crc = ntohs(tailer.crc);
    gen_crc = GenCRCCheck(packet+sizeof(UartHeader), data_len);
    if (crc != gen_crc) {
        err_printf("Crc check err, recv_crc:%x, gen_crc:%x, data_len:%x.\n", crc, gen_crc, data_len);
        return -1;
    }
    
    return 0;
}

//pack protocol
u_int8_t* PackSlaveCtrlCmd(SlaveCtrlCmd* cmd, int* cmd_data_len) {
    char* json_str= NULL;
    char* cmd_data = NULL;
    int i = 0;

    if (cmd == NULL) {
        err_printf("Input err, SlaveCtrlCmd ptr is NULL.\n");
        return NULL;
    }

    cJSON* root_json = cJSON_CreateObject();
    if (root_json == NULL) {
        err_printf("Create json object err.\n");
        return NULL;
    }

    cJSON* hex_json = cJSON_CreateArray();
    if (root_json == NULL) {
        err_printf("Create json array err.\n");
        cJSON_Delete(root_json);
        return NULL;
    }

    cJSON_AddNumberToObject(root_json, "ID", cmd->cmd_id);
    cJSON_AddStringToObject(root_json, "cmd", cmd->cmd_type);
    cJSON_AddStringToObject(root_json, "NO", cmd->cmd_no_realtime);
    for (i = 0; i < cmd->action_hex_num; ++i) {
        cJSON_AddItemToArray(hex_json, cJSON_CreateString(cmd->action_hex[i]));
    }
    cJSON_AddItemToObject(root_json, "hex", hex_json);

    json_str = cJSON_PrintUnformatted(root_json);
    if (json_str == NULL) {
        err_printf("Json print err.\n");
        cJSON_Delete(root_json);
        return NULL;
    }

    cJSON_Delete(root_json);
    cmd_data = UartPacketWrapper(json_str, strlen(json_str));
    *cmd_data_len = strlen(json_str) + sizeof(UartHeader) + sizeof(UartTailer);
    free(json_str);
    return (u_int8_t*)cmd_data;    
}


//parse protocol
int ParseSlaveStatusParam(u_int8_t* data, SlaveStatusParam* param) {
    cJSON* json_item = NULL;

    if (data == NULL || param == NULL) {
        err_printf("Input err, data or param ptr is NULL.\n");
        return -1;
    }

    cJSON* json = cJSON_Parse(data);
    if (json == NULL) {
        err_printf("Json parse err, data:%s.\n", data);
        return -1;
    }

    json_item = cJSON_GetObjectItem(json, "ID");
    if (json_item == NULL) {
        err_printf("Json parse key[ID] err.\n");
        cJSON_Delete(json);
        return -1;
    }
    param->cmd_id = json_item->valueint;

    json_item = cJSON_GetObjectItem(json, "status");
    if (json_item == NULL || json_item->valuestring == NULL) {
        err_printf("Json parse key[status] err.\n");
        cJSON_Delete(json);
        return -1;
    }
    snprintf(param->status, sizeof(param->status), "%s", json_item->valuestring);

    json_item = cJSON_GetObjectItem(json, "NO");
    if (json_item == NULL || json_item->valuestring == NULL) {
        err_printf("Json parse key[NO] err.\n");
        cJSON_Delete(json);
        return -1;
    }
    snprintf(param->cmd_no, sizeof(param->cmd_no), "%s", json_item->valuestring);

    json_item = cJSON_GetObjectItem(json, "degree");
    if (json_item == NULL) {
        err_printf("Json parse key[degree] err.\n");
        cJSON_Delete(json);
        return -1;
    }
    param->degree = json_item->valueint;

    json_item = cJSON_GetObjectItem(json, "alarm");
    if (json_item && json_item->valuestring) {
        snprintf(param->alarm, sizeof(param->alarm), "%s", json_item->valuestring);
    }

    json_item = cJSON_GetObjectItem(json, "motorID");
    if (json_item) {
        if (json_item->valuestring) {
            snprintf(param->motor_id, sizeof(param->motor_id), "%s", json_item->valuestring);
        } else {
            snprintf(param->motor_id, sizeof(param->motor_id), "%d", json_item->valueint);
        }
    }

    cJSON_Delete(json);
    return 0;
}

int ParseSlaveCmdStatusParam(u_int8_t* data, SlaveCmdStatusParam* param) {
    cJSON* json_item = NULL;

    if (data == NULL || param == NULL) {
        err_printf("Input err, data or param ptr is NULL.\n");
        return -1;
    }

    cJSON* json = cJSON_Parse(data);
    if (json == NULL) {
        err_printf("Json parse err, data:%s.\n", data);
        return -1;
    }

    json_item = cJSON_GetObjectItem(json, "ID");
    if (json_item == NULL) {
        err_printf("Json parse key[ID] err.\n");
        cJSON_Delete(json);
        return -1;
    }
    param->cmd_id = json_item->valueint;

    json_item = cJSON_GetObjectItem(json, "status");
    if (json_item == NULL || json_item->valuestring == NULL) {
        err_printf("Json parse key[status] err.\n");
        cJSON_Delete(json);
        return -1;
    }
    snprintf(param->status, sizeof(param->status), "%s", json_item->valuestring);

    json_item = cJSON_GetObjectItem(json, "NO");
    if (json_item == NULL || json_item->valuestring == NULL) {
        err_printf("Json parse key[NO] err.\n");
        cJSON_Delete(json);
        return -1;
    }
    snprintf(param->cmd_no, sizeof(param->cmd_no), "%s", json_item->valuestring);

    json_item = cJSON_GetObjectItem(json, "degree");
    if (json_item == NULL) {
        err_printf("Json parse key[degree] err.\n");
        cJSON_Delete(json);
        return -1;
    }
    param->degree = json_item->valueint;

    cJSON_Delete(json);
    return 0;
}

int ParseSlaveAlarmParam(u_int8_t* data, SlaveAlarmParam* param) {
    cJSON* json_item = NULL;

    if (data == NULL || param == NULL) {
        err_printf("Input err, data or param ptr is NULL.\n");
        return -1;
    }

    cJSON* json = cJSON_Parse(data);
    if (json == NULL) {
        err_printf("Json parse err, data:%s.\n", data);
        return -1;
    }

    json_item = cJSON_GetObjectItem(json, "ID");
    if (json_item == NULL) {
        err_printf("Json parse key[ID] err.\n");
        cJSON_Delete(json);
        return -1;
    }
    param->cmd_id = json_item->valueint;

    json_item = cJSON_GetObjectItem(json, "status");
    if (json_item == NULL || json_item->valuestring == NULL) {
        err_printf("Json parse key[status] err.\n");
        cJSON_Delete(json);
        return -1;
    }
    snprintf(param->status, sizeof(param->status), "%s", json_item->valuestring);

    json_item = cJSON_GetObjectItem(json, "alarm");
    if (json_item == NULL || json_item->valuestring == NULL) {
        err_printf("Json parse key[alarm] err.\n");
        cJSON_Delete(json);
        return -1;
    }
    snprintf(param->alarm, sizeof(param->alarm), "%s", json_item->valuestring);

    json_item = cJSON_GetObjectItem(json, "motorID");
    if (json_item && json_item->valuestring) {
        snprintf(param->motor_id, sizeof(param->motor_id), "%s", json_item->valuestring);
    }

    json_item = cJSON_GetObjectItem(json, "degree");
    if (json_item) {
        param->degree = json_item->valueint;
    }
    

    cJSON_Delete(json);
    return 0;
}

int ParseSlaveCmdRspParam(u_int8_t* data, SlaveCmdRspParam* param) {
    cJSON* json_item = NULL;

    if (data == NULL || param == NULL) {
        err_printf("Input err, data or param ptr is NULL.\n");
        return -1;
    }

    cJSON* json = cJSON_Parse(data);
    if (json == NULL) {
        err_printf("Json parse err, data:%s.\n", data);
        return -1;
    }

    json_item = cJSON_GetObjectItem(json, "ID");
    if (json_item == NULL) {
        err_printf("Json parse key[ID] err.\n");
        cJSON_Delete(json);
        return -1;
    }
    param->cmd_id = json_item->valueint;

    json_item = cJSON_GetObjectItem(json, "status");
    if (json_item == NULL || json_item->valuestring == NULL) {
        err_printf("Json parse key[status] err.\n");
        cJSON_Delete(json);
        return -1;
    }
    snprintf(param->status, sizeof(param->status), "%s", json_item->valuestring);

    json_item = cJSON_GetObjectItem(json, "alarm");
    if (json_item && json_item->valuestring) {
        snprintf(param->alarm, sizeof(param->alarm), "%s", json_item->valuestring);
    }
    

    cJSON_Delete(json);
    return 0;
}
